//
//  untitled.m
//  iChant
//
//  Created by iPhone Dev 2 on 12/22/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "untitled.h"


@implementation untitled

@end
