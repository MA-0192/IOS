//
//  Constants.h
//  iChant
//
//  Created by User on 2/21/13.
//
//

#define kNarration @"narrations"
#define kDisplayLanguages @"displaylanguages"
#define kBeadsArray @"beadsarray"
#define kMalaArray @"malasarray"
#define kSelectedAudioSetting @"selectedaudiosettingarray"
#define kNumberOfTimesArray @"numberoftimesarray"
#define kNumberOfSecondsArray @"numberofsecondarray"