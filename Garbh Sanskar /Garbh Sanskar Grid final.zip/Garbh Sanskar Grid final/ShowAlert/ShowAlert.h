//
//  ShowAlert.h
//  NewsForDragonball
//
//  Created by Sachin Khard on 10/5/12.
//  Copyright (c) 2012 Sachin Khard. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ShowAlert : NSObject

+(void)showMyAlert:(NSString *)title :(NSString *)message;

@end
