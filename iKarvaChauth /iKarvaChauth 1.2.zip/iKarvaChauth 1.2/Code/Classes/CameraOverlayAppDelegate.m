//
//  CameraOverlayAppDelegate.m
//  CameraOverlay
//
//  Created by Media Agility on 8/9/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "CameraOverlayAppDelegate.h"
#import "CameraOverlayViewController.h"

@implementation CameraOverlayAppDelegate

@synthesize window;
@synthesize viewController;
@synthesize imageNumber;
@synthesize navigationController;




- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
    [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationSlide];

//    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] ;
//    // Override point for customization after application launch.
//    self.viewController = [[CameraOverlayViewController alloc] initWithNibName:@"CameraOverlayViewController" bundle:nil] ;
//    navigationController = [[UINavigationController alloc]initWithRootViewController:self.viewController];
//    navigationController.navigationBar.hidden = YES;
//    [self.window addSubview:navigationController.view];

    // Override point for customization after app launch
   
    [window addSubview:viewController.view];
//	[window addSubview:navigationController.view];
     self.window.rootViewController = navigationController;
    [window makeKeyAndVisible];
	
 //   self.navigationController.navigationBar.hidden=YES;
    
		[Appirater appLaunched];
	
	return YES;
	
	
}

-(void)applicationDidEnterBackground:(UIApplication *)application


{
	
	[Appirater appLaunched];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url
{
    
    return [[self.viewController fbObject] handleOpenURL:url];
}

// For 4.2+ support
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    
    return [[self.viewController fbObject] handleOpenURL:url];
}

@end
