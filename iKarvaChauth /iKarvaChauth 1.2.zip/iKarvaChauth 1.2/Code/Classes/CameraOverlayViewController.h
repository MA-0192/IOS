//
//  CameraOverlayViewController.h
//  CameraOverlay
//
//  Created by Media Agility on 8/9/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreGraphics/CoreGraphics.h>
#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>
#import <iAd/iAd.h>
#import "FBConnect.h"
#import <MessageUI/MessageUI.h>
#import <SystemConfiguration/SystemConfiguration.h>
#import "ViewController.h"
@class CameraOverlayAppDelegate;

@interface CameraOverlayViewController : UIViewController <UINavigationControllerDelegate,UIImagePickerControllerDelegate,FBSessionDelegate,FBRequestDelegate,FBDialogDelegate> {

	UIImagePickerController *pickerController;
	UIView *CameraView;
	NSTimer *timer;
	UIImageView *imgView;
	CameraOverlayAppDelegate *appDelegate;
	NSUserDefaults *userDefaultObj;
	NSMutableArray *directoryArray;
	UIImage *screenshot;
	//FBSession *_session;
	//FBRequest *uploadPhotoRequest;
	
	UIImage *logInBtnBG;
	UIImage *logOffBtnBG;
	
	UIButton *login;
	
	UIBarButtonItem *doneButton;
	UIBarButtonItem *flipButton;
	UIView *instructionsView;
	
	UIButton *otherAppsButton;
	UIButton *websiteButton;
	
	UIButton *openCamera;
	ADBannerView *banner;
    UIView *contentView;
	BOOL willLeaveBanner;
	UIButton *feedbackButton;
	UIImage *newImage;
	//UIImagePickerController *picker;
	UIImageView *bannerAlternate;
}
@property (nonatomic, retain) Facebook *fbObject;
@property (retain, nonatomic) IBOutlet UIButton *liberaryBtn;
@property(nonatomic,retain) UIView *CameraView;
@property(nonatomic,retain) NSTimer *timer;
@property(nonatomic,retain) UIImageView *imgView;
@property(nonatomic,retain)	NSUserDefaults *userDefaultObj;
- (IBAction)openLiberary:(id)sender;
@property(nonatomic,retain) NSMutableArray *directoryArray;
@property(nonatomic,retain)	UIImage *screenshot;

@property(nonatomic,retain) UIImage *logInBtnBG;
@property(nonatomic,retain) UIImage *logOffBtnBG;

@property(nonatomic,retain) IBOutlet UIButton *login;

//@property(nonatomic,retain) FBSession *_session;

@property (nonatomic, retain) IBOutlet UIBarButtonItem *doneButton;
@property (nonatomic, retain) UIBarButtonItem *flipButton;
@property (nonatomic, retain) IBOutlet UIView *instructionsView;

@property (nonatomic, retain) IBOutlet UIButton *otherAppsButton;
@property (nonatomic, retain) IBOutlet UIButton *websiteButton;
@property (nonatomic, retain) IBOutlet 	UIButton *feedbackButton;

@property (nonatomic, retain) IBOutlet UIButton *openCamera;
//add banner in main view
@property(nonatomic, retain) ADBannerView *banner;
@property(nonatomic,retain ) IBOutlet UIView *contentView;
@property(nonatomic) BOOL willLeaveBanner;
@property(nonatomic,retain) UIAlertView *alert;
@property(nonatomic) BOOL firstLogin;
@property(nonatomic) BOOL cameraPicked;
@property(nonatomic,retain) UIImage *newImage;
//@property(nonatomic,retain)UIImagePickerController *picker;
@property(nonatomic,retain) UIAlertView *alerts;

@property(nonatomic,retain) UIAlertView *facebookAlerts;
@property(nonatomic,retain) IBOutlet UIImageView *bannerAlternate;
@property(nonatomic,retain )IBOutlet UITextView *textView;

- (IBAction)btn1:(id)sender;
- (IBAction)btn2:(id)sender;
- (IBAction)btn2:(id)sender;
- (IBAction)btn3:(id)sender;


-(IBAction) showCameraClicked;
-(void)login:(id)sender;
- (void)updateFacebookButton;
- (void)flipAction:(id)sender;
-(IBAction)otherAppsButtonPressed:(UIButton *)sender;
-(IBAction)websiteButtonPressed:(UIButton *)sender;
-(void)layoutForCurrentOrientation:(BOOL)animated;// To adjust orientation of view after adding add 
-(void)createADBannerView;  //add banner in view
-(IBAction)iPoojaButtonPressed:(UIButton *)sender;
-(IBAction)iChantButtonPressed:(UIButton *)sender;
-(IBAction)iAtmanButtonPressed:(UIButton *)sender;
-(IBAction)zenageButtonPressed:(UIButton *)sender;
-(IBAction)sendFeedBackButtonPressed:(UIButton *)sender;

-(void)launchMailAppOnDevice;
-(void)displayComposerSheet;



@end

