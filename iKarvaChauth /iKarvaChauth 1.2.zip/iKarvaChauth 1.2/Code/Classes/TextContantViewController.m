//
//  TextContantViewController.m
//  CameraOverlay
//
//  Created by Vivek Yadav on 10/16/13.
//
//

#import "TextContantViewController.h"

@interface TextContantViewController ()

@end

@implementation TextContantViewController
@synthesize textViewText;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    if([[UIScreen mainScreen] bounds].size.height == 480)
    {
        
        [[NSBundle mainBundle]loadNibNamed:@"TextContantViewController" owner:self options:nil];
    }else
    {
        [[NSBundle mainBundle]loadNibNamed:@"TextContantViewController-iphone5" owner:self options:nil];
    }
    BOOL isAtLeast7 = [[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0;
    
    if ( isAtLeast7 ) {
        self.edgesForExtendedLayout=UIRectEdgeNone;
        [[UINavigationBar appearance] setTintColor:[UIColor whiteColor]];
        
    }
    

    textview.text=textViewText;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [textview release];
    [super dealloc];
}
- (void)viewDidUnload {
    [textview release];
    textview = nil;
    [super viewDidUnload];
}
- (IBAction)back:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}
@end
