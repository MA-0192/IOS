//
//  CameraOverlayAppDelegate.h
//  CameraOverlay
//
//  Created by Media Agility on 8/9/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import<SystemConfiguration/SystemConfiguration.h>
#import"Appirater.h"

@class CameraOverlayViewController;

@interface CameraOverlayAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    CameraOverlayViewController *viewController;
	NSInteger imageNumber;
	//UINavigationController *navigationController;
}

@property (nonatomic, retain) UINavigationController *navigationController;
@property (strong, nonatomic) CameraOverlayViewController *viewController;
@property (nonatomic, retain) IBOutlet UIWindow *window;
//@property (nonatomic, retain) IBOutlet CameraOverlayViewController *viewController;
@property (nonatomic) NSInteger imageNumber;
//@property (nonatomic,retain) IBOutlet UINavigationController *navigationController;


@end

