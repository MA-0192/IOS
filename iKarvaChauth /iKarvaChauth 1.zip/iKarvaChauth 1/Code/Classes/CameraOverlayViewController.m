//
//  CameraOverlayViewController.m
//  CameraOverlay
//
//  Created by Media Agility on 8/9/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "CameraOverlayViewController.h"
#import "CameraOverlayAppDelegate.h"
//#import "FBConnect/FBConnect.h"
#import "TextContantViewController.h"
/*static NSString* kApiKey = @"121ef1ae6f4304bcf16dfd0acd75b052";
static NSString* kApiSecret = @"edc3a7bd0c73071a17f3c6056b4f690d"; // @"<YOUR SECRET KEY>";
static NSString* kGetSessionProxy = nil; // @"<YOUR SESSION CALLBACK)>";*/


@implementation CameraOverlayViewController
@synthesize CameraView;
@synthesize timer;
@synthesize imgView;
@synthesize userDefaultObj;
@synthesize directoryArray;
@synthesize screenshot;
//@synthesize _session;
@synthesize logInBtnBG;
@synthesize logOffBtnBG;
@synthesize login;
@synthesize doneButton;
@synthesize flipButton;
@synthesize instructionsView;
@synthesize otherAppsButton;
@synthesize websiteButton;
@synthesize openCamera;
@synthesize banner;
@synthesize contentView;
@synthesize willLeaveBanner;
@synthesize alert;
@synthesize feedbackButton;
@synthesize firstLogin;
@synthesize cameraPicked;
@synthesize newImage;
//@synthesize picker;
@synthesize alerts;
@synthesize  facebookAlerts;
@synthesize bannerAlternate;
@synthesize textView;
@synthesize fbObject;
-(void)viewWillAppear:(BOOL)animated 
{
	/*if (kGetSessionProxy) {
		_session = [[FBSession sessionForApplication:kApiKey getSessionProxy:kGetSessionProxy
											delegate:self] retain];
	} else {
		_session = [[FBSession sessionForApplication:kApiKey secret:kApiSecret delegate:self] retain];
	}
	[_session resume];
	
	[self updateFacebookButton];*/
	
	[super viewWillAppear:animated];
}

/*-(void)login:(id)sender
{
	firstLogin= YES;
	if([_session isConnected] == YES)
	{
		[_session logout];
	}
	else 
	{
		//[_session release];
		FBLoginDialog* dialog = [[[FBLoginDialog alloc] initWithSession:_session] autorelease];
		[dialog show];
		
			}
}

- (void)updateFacebookButton
{
	logInBtnBG = [[[UIImage imageNamed:@"connect.png"] stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0] retain];
	logOffBtnBG = [[[UIImage imageNamed:@"logout.png"] stretchableImageWithLeftCapWidth:12.0 topCapHeight:0.0] retain];
	NSLog(@"session connected %d",[_session isConnected]);
	[login setImage:(([_session isConnected] == YES) ? logOffBtnBG : logInBtnBG) forState:UIControlStateNormal];
	
	 //
	
}

// Facebook publish
- (IBAction)sendFacebookUpdate
{
	if([_session isConnected] == YES)
	{
		FBStreamDialog* dialog1 = [[[FBStreamDialog alloc] init] autorelease];
		dialog1.delegate = self;
		dialog1.userMessagePrompt = @"Example prompt";
		
		//NSString *str = [[NSString alloc ]initWithFormat:@"{\"name\":\"iKarvaChauth\",\"href\":\kIchantAppURL,\"caption\":\"I am using the new iKarvaChauth app on my iPhone \",\"media\":[{\"type\":\"image\",\"src\":\kLogo,\"href\":\kZenageURL}]}"];
		NSLog(@"string %@",kItunesURL);
		NSString *str = [[NSString alloc ]initWithFormat:@"{\"name\":\"iKarvaChauth\",\"href\":\"http://itunes.com/apps/ichantbliss\",\"caption\":\"I am using the new iKarvaChauth app on my iPhone \",\"media\":[{\"type\":\"image\",\"src\":\"http://www.images.zenagestudios.com/iKarvaChauth_Logo.png\",\"href\":\"http://www.zenagestudios.com\"}]}"];
		//NSString *str = [[NSString alloc ]initWithFormat:@"{\"name\":\"iKarvaChauth\",\"href\":\"http://itunes.com/apps/ichantbliss\",\"caption\":\"I am using the new iKarvaChauth app on my iPhone \",\"media\":[{\"type\":\"image\",\"src\":\"karwa-logo.png\",\"href\":\"http://www.zenagestudios.com\"}]}"];
		dialog1.attachment = str;        
		
		// replace this with a friend's UID
		// dialog.targetId = @"999999";
		[dialog1 show];
	}
	
	
}*/




// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad 
{

    if([[UIScreen mainScreen] bounds].size.height == 480)
    {
    
     [[NSBundle mainBundle]loadNibNamed:@"CameraOverlayViewController" owner:self options:nil];
    }else
    {
         [[NSBundle mainBundle]loadNibNamed:@"CameraOverlayViewController-iphone5" owner:self options:nil];
    }
    BOOL isAtLeast7 = [[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0;
    
    if ( isAtLeast7 ) {
        self.edgesForExtendedLayout=UIRectEdgeNone;
    }

  
	//[self createADBannerView];
	
	self.view.backgroundColor=[UIColor blackColor];
	self.contentView.backgroundColor= [UIColor blackColor];
	self.title = @"iKarvaChauth";
	self.navigationController.navigationBar.barStyle = UIBarStyleBlackOpaque;
		
	UIButton* infoButton = [UIButton buttonWithType:UIButtonTypeInfoLight];
	[infoButton addTarget:self action:@selector(flipAction:) forControlEvents:UIControlEventTouchUpInside];
	flipButton = [[UIBarButtonItem alloc] initWithCustomView:infoButton];
	flipButton.title = @"Done";
	
	self.navigationItem.rightBarButtonItem = flipButton;
	
	[openCamera setTitle:@"Open Camera" forState:UIControlStateNormal];
	willLeaveBanner=NO;
	
	firstLogin=NO;
	
	
	NSMutableString * string=[[NSMutableString alloc]initWithString:@"iKarvaChauth is an innovative product for \n the  iPhone and other iOS camera enabl\ned  devices. ZenAge Studios continues to\nrelease such applications with the mission \nto preserve and pass on the cultural herit-\nage to the new generation on the devices\nthey  are   familiar  with. This   application \nmakes practical use of the camera as the\nchalni  or sieve to  be  used  during    the\nKarvaChauth   ceremony.  You  can  then\nupload the photograph to your  Facebook\naccount.We hope you enjoy iKarvaChauth"];
	self.textView.text= string;
	
	
	
	[super viewDidLoad];
}

- (void)flipAction:(id)sender
{
	[UIView setAnimationDelegate:self];
	[UIView setAnimationDidStopSelector:@selector(animationDidStop:animationIDfinished:finished:context:)];
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.75];
	
	[UIView setAnimationTransition:([self.view superview] ?
									UIViewAnimationTransitionFlipFromRight : UIViewAnimationTransitionFlipFromLeft)
						   forView:self.view cache:YES];
	//instructionsView.backgroundColor = [UIColor clearColor];
	
	if ([instructionsView superview])
	{
		[instructionsView removeFromSuperview];
	}
	else
	{
		[self.view addSubview:instructionsView];
    }
	
	[UIView commitAnimations];
	
	// adjust our done/info buttons accordingly
	
	if ([instructionsView superview] == self.view)
	{
		self.navigationItem.rightBarButtonItem = doneButton;
	}
	else
		self.navigationItem.rightBarButtonItem = flipButton;
}



-(IBAction)otherAppsButtonPressed:(UIButton *)sender
{
	
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:kItuneZenage]];
	
}

-(IBAction)websiteButtonPressed:(UIButton *)sender
{
	
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString: kZenageURL]];
	
}
-(IBAction)iPoojaButtonPressed:(UIButton *)sender
{
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:kIpooja]];	
}
-(IBAction)iChantButtonPressed:(UIButton *)sender
{
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:kIchant]];
}
-(IBAction)iAtmanButtonPressed:(UIButton *)sender
{
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:kIatman]];
	
}
-(IBAction)zenageButtonPressed:(UIButton *)sender
{
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:kZenageURL]];
	
}

- (IBAction)btn1:(id)sender {
    TextContantViewController *vw=[[TextContantViewController alloc]init];
    [vw setTextViewText:@"The fast of Karwa Chauth is of particular importance to all Hindu married women in India. They believe that the festival ensures prosperity, longevity and well-being of their husbands. The origin of this festival was based on a very sweet and noble idea. Though this idea has lost its true sense as today the whole outlook of this festival has changed.\n\nIn the ancient time, girls used to get married at a very early stage, and had to go and live with their in-laws in other villages. After marriage, if she faces any problem with her in-laws or her husband, she would have no one to talk to or seek support from. There used to be no telephones, buses and trains long ago. Her own parents and relatives would be quite far and unreachable. Thus the custom started that, at the time of marriage, when bride would reach her in-laws, she would befriend another woman there who would be her friend or sister for life. It would be like god-friends or god-sisters. Their friendship would be sanctified through a small Hindu ceremony right during the marriage.\n\nOnce the bride and this woman had become god-friends or god-sisters, they would remain so all their lives and recognize the relation as such. They would also treat each other like real sisters.\n\nLater in life, if she faces any difficulty related to her husband or in-laws, she would be able to confidently talk or seek help from each other. Thus, Karwa Chauth was started to as a festival to celebrate this relationship between the once-brides and their god-friends (god-sisters). Fasting and praying for husband came later and is secondary. It was probably added, along with other mythical tales, to enhance the festival. The husband would always be associated with this festival, because the day of starting this holy friendship between two god-sisters was essentially the day of bride's marriage to him. Thus, praying and fasting for him by his wife during a celebration of her relationship with the god-friend would be quite logical.\n\nHence, the festival of Karwa Chauth was to renew and celebrate the relationship between god-friends (god-sisters). It had a tremendous social and cultural significance when world was not having the way to communicate and move around easily."];
    [self.navigationController pushViewController:vw animated:YES];
    vw=Nil;
    
}

- (IBAction)btn2:(id)sender {
    TextContantViewController *vw=[[TextContantViewController alloc]init];
    [vw setTextViewText:@"Karwa Chauth Puja Process\n\nThe fast of Karwa Chauth is kept 9 days before Diwali. It falls on the fourth day of the Kartik month by the Hindu calendar (fourth day of the waning moon or the dark fortnight).\n\nThe Ritual\n\nKarwa Chauth is considered one of the most importantfasts observed by the married Hindu women. On this day the women pray for the welfare and long life of their husbands. The festival is followed mainly in the northern parts of the country.\n\nMarried women eat food early in the morning, before sunrise. They are not supposed to eat or even drink water during the day. In the evening the ladies listen to the Karwa Chauth Katha (the legend). The fast is over after the moonrise.\n\nThe Puja Process\n\nThe pooja preparations start a day in advance. Married women buy the shringar or the traditional adornments and the other pooja items like the karwa, matthi, heena etc.\n\nEarly in the morning they prepare food and have it before sunrise. The morning passes by in other festive activities like decorating hand and feet with heena, decorating thepooja thali and meeting friends and relatives.\n\nIn the late afternoon women gather at a common place like temple or a garden or someones' place who has arranged the pooja. An elderly lady or the pujarin narrates the legend of Karwa Chouth.\n\nThe essentials of this gathering and listening of the Karwa chauth story , a special mud pot, that is considered a symbol of lord Ganesha, a metal urn filled with water, flowers, idols of Ambika Gaur Mata, Goddess Parwati and some fruits, mathi and food grains. A part of this is offered to the deities and the storyteller.\n\nEarlier an idol of Gaur Mata was made using earth and cowdung. Now just an idol of Goddess Parwati is kept. Every one lights an earthen lamp in their thalis while listening to the Karwa story. Sindoor, incense sticks and rice are also kept in the thali.\n\nAt this time the women wear heavy saris or chunries in red , pink or other bridal colors, and adorn themselves with all other symbols of a married women like, nose pin, tika, bindi, chonp, bangles, earrings etc.\n\nOnce the moon rises, the women see its reflection in a thali of water, or through a dupatta or a sieve. They offer water to the moon and seek blessings. They pray for the safety, prosperity and long life of their husbands. This marks the end of the day long fast."];
    [self.navigationController pushViewController:vw animated:YES];
    vw=Nil;
}

- (IBAction)btn3:(id)sender {
    TextContantViewController *vw=[[TextContantViewController alloc]init];
    [vw setTextViewText:@"Karva Chauth Story\n\n'A long long time ago, there lived a beautiful princess by the name of Veeravati. When she was of the marriageable age, Veeravati was married to a king. On the occasion of the first Karva Chauth after her marriage, she went to her parents’ house.'\n\n'After sunrise, she observed a strict fast. However, the queen was too delicate and couldn’t stand the rigours of fasting. By evening, Veeravati was too weak, and fainted. Now, the queen had seven brothers who loved her dearly. They couldn’t stand the plight of their sister and decided to end her fast by deceiving her. They made a fire at the nearby hill and asked their sister to see the glow. They assured her that it was the moonlight and since the moon had risen, she could break her fast.'\n\n'However, the moment the gullible queen ate her dinner, she received the news that her husband, the king, was dead. The queen was heartbroken and rushed to her husband’s palace. On the way, she met Lord Shiva and his consort, Goddess Parvati. Parvati informed her that the king had died because the queen had broken her fast by watching a false moon. However, when the queen asked her for forgiveness, the goddess granted her the boon that the king would be revived but would be ill.'\n\n'When the queen reached the palace, she found the king lying unconscious with hundreds of needles inserted in his body. Each day, the queen managed to remove one needle from the king’s body. Next year, on the day of Karva Chauth, only one needle remained embedded in the body of the unconscious king.'\n\n'The queen observed a strict fast that day and when she went to the market to buy the karva for the puja , her maid removed the remaining needle from the king’s body. The king regained consciousness, and mistook the maid for his queen. When the real queen returned to the palace, she was made to serve as a maid.'\n\n'However, Veeravati was true to her faith and religiously observed the Karva Chauth vrat . Once when the king was going to some other kingdom, he asked the real queen (now turned maid) if she wanted anything. The queen asked for a pair of identical dolls. The king obliged and the queen kept singing a song ' Roli ki Goli ho gayi... Goli ki Roli ho gayi ' (the queen has turned into a maid and the maid has turned into a queen).'\n\n'On being asked by the king as to why did she keep repeating that song, Veeravati narrated the entire story. The king repented and restored the queen to her royal status. It was only the queen’s devotion and her faith that won her husband’s affection and the blessings of Goddess Parvati.'"];
    [self.navigationController pushViewController:vw animated:YES];
    vw=Nil;
}


-(IBAction) showCameraClicked
{
	
	cameraPicked= YES; 
	firstLogin=NO;
	
	if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]==YES)
	{firstLogin= NO;
			
		UIImage *image = [UIImage imageNamed:@"karwachauth-channi(4).png"] ;
		imgView = [[UIImageView alloc] initWithImage:image] ;
        
        if([[UIScreen mainScreen] bounds].size.height == 480)
        {	imgView.bounds = CGRectMake(0,0, 320, 431) ;
        }else
        {	imgView.bounds = CGRectMake(0,0, 320, 490) ;
            
        }
        
	
				
		pickerController = [[UIImagePickerController alloc] init];
				
		// Hide Apple's UI
		pickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
		pickerController.delegate = self;
		pickerController.showsCameraControls = YES;
		pickerController.wantsFullScreenLayout = YES;
		pickerController.allowsEditing = NO;
				
	
		// Add the view to be overlaid
		pickerController.cameraOverlayView = imgView ;
		[imgView release] ;
	
				
		// Show the camera's view as a modal dialog.
		[self presentModalViewController:pickerController animated:YES];

	}
	else
	{
		UIAlertView* cameraAlert;
		cameraAlert = [[UIAlertView alloc] 
									initWithTitle:@"Camera Error" 
									message:@"No camera in your device" 
									delegate:self 
									cancelButtonTitle: @"OK" 
									otherButtonTitles:nil];    
			[cameraAlert show];     
			[cameraAlert release];
		return;
			
	}
}


#pragma mark  -
#pragma mark ADBannerViewDelegate methods

- (void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationSlide];

    if (cameraPicked==NO) {
      
    
    ViewController *vw=[[ViewController alloc]init];
    [vw setImagePhoto:[info objectForKey:UIImagePickerControllerOriginalImage]];
    [vw setFbObject:fbObject];
    [self.navigationController pushViewController:vw animated:YES];
}
else
{
    
    
    ViewController *vw=[[ViewController alloc]init];
    [vw setImagePhoto:[info objectForKey:UIImagePickerControllerOriginalImage]];
    [vw setFbObject:fbObject];
    [self.navigationController pushViewController:vw animated:YES];
    
//	firstLogin=NO;
//	NSLog(@"picked");
//	
//	cameraPicked= YES;
//	appDelegate = (CameraOverlayAppDelegate *)[[UIApplication sharedApplication] delegate];
//	
//	//UIScreen *sc = [UIScreen mainScreen];
//	//CGRect rect = sc.bounds;
//	
//	
//	
//	CGSize contextSize=CGSizeMake(320,427);
//	UIGraphicsBeginImageContext(contextSize);
//	[picker.view.layer renderInContext:UIGraphicsGetCurrentContext()];
//	screenshot = UIGraphicsGetImageFromCurrentImageContext();
//	UIGraphicsEndImageContext();
//	
//	
//	firstLogin= NO;
//	NSLog(@"saved in document directory");
//	//Saving in Documents Dir
//	NSData *data = UIImageJPEGRepresentation(screenshot, 1.0);
//	NSFileManager *fileManager = [NSFileManager defaultManager];
//	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask,  YES);
//	NSString *documentsDirectory = [paths objectAtIndex:0];
//    NSString *str=[NSString stringWithFormat:@"image.jpg",screenshot];
//	NSString *fullPath = [documentsDirectory stringByAppendingPathComponent:str];
//	[fileManager createFileAtPath:fullPath contents:data attributes:nil];
//	
//	NSLog(@"alert messages");
//		
//	UIImageWriteToSavedPhotosAlbum(screenshot, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
//
}
	[picker dismissModalViewControllerAnimated:YES ];
		
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationSlide];

	firstLogin= NO;
	
	NSLog(@"SAVE PHOTO");
	// Unable to save the image
	if (error)
	{
		alert = [[UIAlertView alloc] initWithTitle:@"Error"
									 message:@"Unable to save image to Photo Album."
									 delegate:self cancelButtonTitle:@"Ok"
									 otherButtonTitles:nil];
	[alert show];
	[alert release];
	}
	 else //if([_session isConnected] == NO)
	  {
		alert = [[UIAlertView alloc] initWithTitle:@"Success"
									 message:@"Photo saved to Camera Roll in Photos App."
									 delegate:self cancelButtonTitle:@"Ok"
									 otherButtonTitles:nil];
		  [alert show];
		  [alert release];
		  return;
	  }
	

	/*else if([_session isConnected] == YES)
	{
	   alerts = [[UIAlertView alloc] initWithTitle:@"Success"
										   message:@"Do you want to upload to Facebook?"
										  delegate:self cancelButtonTitle:@"YES"
								 otherButtonTitles:@"NO",nil];
		
		[alerts show];
		[alerts release];
	}*/

}


/*-(void)createADBannerView
{
	NSString *contentSize = UIInterfaceOrientationIsPortrait(self.interfaceOrientation) ? ADBannerContentSizeIdentifier320x50 : ADBannerContentSizeIdentifier480x32;
	// set the frame of banner
	CGRect frame;
    frame.size = [ADBannerView sizeFromBannerContentSizeIdentifier:contentSize];
    frame.origin = CGPointMake(0.0, CGRectGetMaxY(self.view.bounds));
	
	
    ADBannerView *bannerView = [[ADBannerView alloc] initWithFrame:frame];
    
    bannerView.delegate = self;
    
    bannerView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleTopMargin;
    
    bannerView.requiredContentSizeIdentifiers = [NSSet setWithObjects:ADBannerContentSizeIdentifier320x50, ADBannerContentSizeIdentifier480x32, nil];
    
	//if(bannerLoaded)
    // At this point the ad banner is now be visible and looking for an ad.
    [self.view addSubview:bannerView];
    self.banner = bannerView;
    [bannerView release];
	
	
}*/
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationSlide];

    [picker  dismissModalViewControllerAnimated:YES];
}
//- (void) imagePickerController: (UIImagePickerController *) picker
// didFinishPickingMediaWithInfo: (NSDictionary *) info
//{
//   // UIImage *image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
//    [picker dismissModalViewControllerAnimated:YES];
////    chooseImage=image;
// //   [cameraBtn setImage:image forState:UIControlStateNormal];
//    
//}
- (void)createADBannerView
{
	Class cls = NSClassFromString(@"ADBannerView");
	
    if (cls) {
		
        ADBannerView *adView = [[cls alloc] initWithFrame:CGRectZero];
		
        adView.requiredContentSizeIdentifiers = [NSSet setWithObjects:
												 
												 ADBannerContentSizeIdentifier320x50,
												 
												 ADBannerContentSizeIdentifier480x32,
												 
												 nil];
		
		
		
        // Set the current size based on device orientation
		
        adView.currentContentSizeIdentifier = ADBannerContentSizeIdentifier320x50;
		
		adView.delegate = self;
		
		
		
		adView.autoresizingMask = UIViewAutoresizingFlexibleTopMargin |
		
		UIViewAutoresizingFlexibleRightMargin;
		
		
		
        // Set initial frame to be offscreen
		
        CGRect bannerFrame =adView.frame;
		
        bannerFrame.origin.y = self.view.frame.size.height;
		
        adView.frame = bannerFrame;
		
		
		
        self.banner = adView;
		
        [self.view addSubview:adView];
		
        [adView release];
		
    }
	
}

-(void)layoutForCurrentOrientation:(BOOL)animated
{
    CGFloat animationDuration = animated ? 0.2 : 0.0;
    
    CGRect contentFrame = self.view.bounds;
    
    CGPoint bannerCenter = CGPointMake(CGRectGetMidX(contentFrame), CGRectGetMaxY(contentFrame));
    CGFloat bannerHeight = 0.0;
    
    // First, setup the banner's content size and adjustment based on the current orientation
    if(UIInterfaceOrientationIsLandscape(self.interfaceOrientation))
    {
        banner.currentContentSizeIdentifier = ADBannerContentSizeIdentifier480x32;
        bannerHeight = 32.0;
    }
    else
    {
        banner.currentContentSizeIdentifier = ADBannerContentSizeIdentifier320x50;
        bannerHeight = 50.0;
    }
	
    if(banner.bannerLoaded)
    {
        contentFrame.size.height -= bannerHeight;
        bannerCenter.y -= bannerHeight / 2.0;
    }
    else
    {
        bannerCenter.y += bannerHeight / 2.0;
    }
    
    // And finally animate the changes, running layout for the content view if required.
    [UIView animateWithDuration:animationDuration
                     animations:^{
                         contentView.frame = contentFrame;
                         [contentView layoutIfNeeded];
                         
                         banner.center = bannerCenter;
                     }];
}

#pragma mark ADBannerViewDelegate methods

-(void)bannerViewDidLoadAd:(ADBannerView *)banner
{
    //[self layoutForCurrentOrientation:YES];
	
	NSLog(@"banner loaded successfully");
    [self layoutForCurrentOrientation:YES];
	[self.view layoutIfNeeded];
}

-(void)bannerView:(ADBannerView *)banner didFailToReceiveAdWithError:(NSError *)error
{
    //[self layoutForCurrentOrientation:YES];
	NSLog(@"problem in loading ad frm network");
	[self layoutForCurrentOrientation:YES];
	
}

-(BOOL)bannerViewActionShouldBegin:(ADBannerView *)banner willLeaveApplication:(BOOL)willLeave
{
	NSLog(@"banner tapped");
	
	willLeaveBanner=YES;

	
	
    return YES;
}

-(void)bannerViewActionDidFinish:(ADBannerView *)banner
{
	NSLog(@"banner has done its action");
	
}



- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}


/////////////////////////////////////////////////////////////////
// FBSessionDelegate

/*- (void)session:(FBSession*)session didLogin:(FBUID)uid {
	//_label.text = @"";
	
	if([_session isConnected] == YES &&  firstLogin==YES )
	{
		
	[self performSelector:@selector(sendFacebookUpdate)];
	NSLog(@"logged in facebook");
	facebookAlerts = [[UIAlertView alloc] 
								  initWithTitle:@"Photo Upload to Facebook" 
								  message:@"Login to Facebook on your PC to approve for publishing" 
								  delegate:self 
								  cancelButtonTitle: @"OK" 
								  otherButtonTitles:nil]; 
	[facebookAlerts show];
	[facebookAlerts release];
	
	
		
	}
	
	
	NSLog(@"logged");
	[self updateFacebookButton];
	
	
	firstLogin=NO;
	//[self sendFacebookStatus];
	
	}


- (void)sessionDidNotLogin:(FBSession*)session {
	
	NSLog(@"Canceled login");
}


- (void)sessionDidLogout:(FBSession*)session {
	NSLog(@"Disconnected");
	[self updateFacebookButton];
	firstLogin=YES;
	
}*/


//feedback methods
-(IBAction)sendFeedBackButtonPressed:(UIButton *)sender
{
	
	Class mailClass = (NSClassFromString(@"MFMailComposeViewController"));
	if (mailClass != nil)
	{
		// We must always check whether the current device is configured for sending emails
		if ([mailClass canSendMail])
		{
			[self displayComposerSheet];
		}
		else
		{
			[self launchMailAppOnDevice];
		}
	}
	else
	{
		[self launchMailAppOnDevice];
	}
}
-(void)launchMailAppOnDevice
{
	
	NSString *recipients = @"mailto:helpdesk@zenagestudios.com?&subject=Feedback !";
	NSString *body = @"&body= ";
	
	NSString *email = [NSString stringWithFormat:@"%@%@",recipients, body];
	email = [email stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	
	[[UIApplication sharedApplication] openURL:[NSURL URLWithString:email]];
}
// Displays an email composition interface inside the application. Populates all the Mail fields. 
-(void)displayComposerSheet 
{
	NSLog(@"In display composer sheeth");
	
	MFMailComposeViewController *picker1 = [[MFMailComposeViewController alloc] init];
	picker1.mailComposeDelegate = self;
	
	[picker1 setSubject:@"Feedback iKarvaChauth"];
	
	
	// Set up recipients
	NSArray *toRecipients = [NSArray arrayWithObject:@"helpdesk@zenagestudios.com"]; 
	[picker1 setToRecipients:toRecipients];
	
	
	// Fill out the email body text
	NSString *emailBody = @"";
	[picker1 setMessageBody:emailBody isHTML:NO];
	
	[self presentModalViewController:picker1 animated:YES];
	[picker1 release];
}
// Dismisses the email composition interface when users tap Cancel or Send. Proceeds to update the message field with the result of the operation.
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error 
{        
	//message.hidden = NO;
	// Notifies users about errors associated with the interface
	switch (result)
	{
		case MFMailComposeResultCancelled:
			NSLog(@"mail sending cancaled");
			break;
		case MFMailComposeResultSaved:
			NSLog(@"mail results saved"); 
			break;
		case MFMailComposeResultSent:
			NSLog(@"mail sent sucessfully");
			break;
		case MFMailComposeResultFailed:
			NSLog(@"mail results failed");
			break;
		default:
			
			break;
	}
	[self dismissModalViewControllerAnimated:YES];
}

#pragma mark -
#pragma mark alertViewDelegate  method


-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
		
if(alertView  == alerts)
{
	NSLog(@"alert tapped");
	switch (buttonIndex) 
	{
		case 0:	
		{
			//NSArray *paths1 = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES); 
			//NSString *documentsDirectory = [paths1 objectAtIndex:0];
			//NSFileManager *manager = [NSFileManager defaultManager];
			//NSArray *fileListArray =  [manager  directoryContentsAtPath:documentsDirectory];
			//NSMutableArray  *fileList = [[NSMutableArray alloc] initWithArray:fileListArray];
			
			NSString *str1 = [NSBundle pathForResource:@"image" ofType:@"jpg" inDirectory:[NSHomeDirectory() stringByAppendingString:@"/Documents/"]];
			
			newImage = [UIImage imageWithData:[NSData dataWithContentsOfFile: str1]];
			NSLog(@"image %@",self.newImage);
			
			NSMutableDictionary *args = [[[NSMutableDictionary alloc] init] autorelease];
				[args setObject:self.newImage forKey:@"image"];  
			
				NSDictionary *params = nil;
			
			
        
			//[[FBRequest requestWithDelegate:self] call:@"facebook.photos.upload" params:params dataParam:(NSData*)newImage];
			//UIImageWriteToSavedPhotosAlbum(newImage, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);

			//cancel
		}
			break;
		case 1:{
			/*NSArray *paths1 = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES); 
			NSString *documentsDirectory = [paths1 objectAtIndex:0];
			NSFileManager *manager = [NSFileManager defaultManager];
			NSArray *fileListArray =  [manager  directoryContentsAtPath:documentsDirectory];
			NSMutableArray  *fileList = [[NSMutableArray alloc] initWithArray:fileListArray];*/
			
			NSString *str1 = [NSBundle pathForResource:@"image" ofType:@"jpg" inDirectory:[NSHomeDirectory() stringByAppendingString:@"/Documents/"]];
			
			newImage = [UIImage imageWithData:[NSData dataWithContentsOfFile: str1]];
			NSLog(@"image %@",self.newImage);
			
			//NO
			//UIImageWriteToSavedPhotosAlbum(newImage, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
		}
			break;
	}
}	
	
}

-(void)viewDidUnload
{
    [self setLiberaryBtn:nil];
    self.contentView = nil;
	if (self.banner)
	{
		banner.delegate = nil;
		self.banner = nil;
	}
}

-(void)dealloc
{
    [self.contentView release]; 

	if (banner)
	{
		banner.delegate = nil;
		[banner release];
	}
	
	[self.flipButton release];
	[self.alert release];
	[self.alerts release];
	
	[self.facebookAlerts release];
	[self.imgView release];
    [_liberaryBtn release];
    [super dealloc];
}




- (IBAction)openLiberary:(id)sender {
    
    cameraPicked= NO;
    
  
    
    UIImagePickerController* picker = [[UIImagePickerController alloc] init];
    picker.sourceType =UIImagePickerControllerSourceTypePhotoLibrary;
    picker.delegate = self;
  //  picker.allowsImageEditing = NO;
   // 	picker.cameraOverlayView=image ;
    
    
    [self.navigationController presentModalViewController:picker animated:YES];
    
    
    
//    [controller presentModalViewController: mediaUI animated: YES];
    

    [imgView release] ;
	
    
    // Show the camera's view as a modal dialog.
   // [self presentModalViewController:pickerController animated:YES];
    
//    [self.view addSubview:self.kenView];
//    self.kenView.layer.borderWidth = 1;
//    self.kenView.layer.borderColor = [UIColor grayColor].CGColor;
//    self.kenView.delegate = self;
//    NSArray *myImages = [NSArray arrayWithObjects:
//                         [UIImage imageNamed:@"recipe_img_1.jpg"],
//                         [UIImage imageNamed:@"recipe_img_2.jpg"],
//                         [UIImage imageNamed:@"recipe_img_3.jpg"],
//                         [UIImage imageNamed:@"recipe_img_4.jpg"],
//                         nil];
//    
//    
//    [self.kenView animateWithImages:myImages
//                 transitionDuration:15
//                               loop:YES
//                        isLandscape:YES];
}
@end
