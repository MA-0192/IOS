//
//  ViewController.h
//  CameraOverlay
//
//  Created by Vivek Yadav on 10/15/13.
//
//
#import <Twitter/Twitter.h>
#import <UIKit/UIKit.h>
#import "ViewController.h"
#import "FBConnect.h"
@interface ViewController : UIViewController<FBSessionDelegate,FBRequestDelegate,FBDialogDelegate>
{
    	UIImage *screenshot;
    UIAlertView *alert;
}
@property (retain, nonatomic) IBOutlet UIImageView *imkageview;
@property (retain, nonatomic) IBOutlet UIImageView *imageDefault;
@property (nonatomic, retain) Facebook *fbObject;
- (IBAction)saveBtnAction:(id)sender;
- (IBAction)backBtnAction:(id)sender;
- (IBAction)tweeterBtn:(id)sender;
- (IBAction)fbBtn:(id)sender;
@property (retain ,nonatomic) UIImage *imagePhoto;
@end
