//
//  Constants.h
//  CameraOverlay
//
//  Created by Media Agility on 9/29/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Constants : NSObject {
	
 
#define kItunesURL @"http://itunes.com/apps/ichantbliss"
#define kImageURL @"http://www.mediaagility.com/karwa_logo_inside.png" 




	
#define kZenageURL @"http://www.zenagestudios.com"
#define  kItuneZenage @"http://itunes.com/apps/zenagestudios"
#define kIpooja @"http://itunes.apple.com/us/app/ipooja/id355389118?mt=8"
#define kIchant @"http://itunes.apple.com/us/app/ichant-bliss/id352811403?mt=8"
#define kIatman @"http://itunes.apple.com/us/app/aatman/id375314504?mt=8"
	
	
	
}

@end
