//
//  TextContantViewController.h
//  CameraOverlay
//
//  Created by Vivek Yadav on 10/16/13.
//
//

#import <UIKit/UIKit.h>

@interface TextContantViewController : UIViewController

{
    
    IBOutlet UITextView *textview;
}
- (IBAction)back:(id)sender;
@property(nonatomic,strong )NSString *textViewText;
@end
