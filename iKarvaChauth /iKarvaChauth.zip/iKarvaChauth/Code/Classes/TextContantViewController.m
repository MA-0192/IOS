//
//  TextContantViewController.m
//  CameraOverlay
//
//  Created by Vivek Yadav on 10/16/13.
//
//

#import "TextContantViewController.h"

@interface TextContantViewController ()

@end

@implementation TextContantViewController
@synthesize textViewText;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    textview.text=textViewText;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [textview release];
    [super dealloc];
}
- (void)viewDidUnload {
    [textview release];
    textview = nil;
    [super viewDidUnload];
}
- (IBAction)back:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
}
@end
