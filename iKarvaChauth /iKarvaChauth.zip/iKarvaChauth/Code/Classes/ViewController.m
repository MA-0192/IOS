//
//  ViewController.m
//  CameraOverlay
//
//  Created by Vivek Yadav on 10/15/13.
//
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize imagePhoto;
@synthesize fbObject;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
     [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationSlide];
    
    if([[UIScreen mainScreen] bounds].size.height == 480)
    {
        
        [[NSBundle mainBundle]loadNibNamed:@"ViewController" owner:self options:nil];
    }else
    {
        [[NSBundle mainBundle]loadNibNamed:@"ViewController-iphone5" owner:self options:nil];
    }
    
    BOOL isAtLeast7 = [[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0;
    
    if ( isAtLeast7 ) {
        self.edgesForExtendedLayout=UIRectEdgeNone;
    }

    self.imkageview.image=imagePhoto;
   // UIImage *image =  ;
    
    
    self.imageDefault.image=[UIImage imageNamed:@"karwachauth-channi(4).png"];
//    UIImageView * imgView = [[UIImageView alloc] initWithImage:image] ;
//    imgView.bounds = self.imkageview.bounds;
//    [self.imkageview addSubview:imgView];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_imkageview release];
    [_imageDefault release];
    [super dealloc];
}
- (void)viewDidUnload {
    [self setImkageview:nil];
    [self setImageDefault:nil];
    [super viewDidUnload];
}
- (IBAction)saveBtnAction:(id)sender {
    
     CGSize contextSize=CGSizeMake(320,427);
	UIGraphicsBeginImageContext(contextSize);
	[self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
	screenshot = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	
	
//	firstLogin= NO;
	NSLog(@"saved in document directory");
	//Saving in Documents Dir
	NSData *data = UIImageJPEGRepresentation(screenshot, 1.0);
	NSFileManager *fileManager = [NSFileManager defaultManager];
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask,  YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *str=[NSString stringWithFormat:@"image.jpg",screenshot];
	NSString *fullPath = [documentsDirectory stringByAppendingPathComponent:str];
	[fileManager createFileAtPath:fullPath contents:data attributes:nil];
	
	NSLog(@"alert messages");
    
	UIImageWriteToSavedPhotosAlbum(screenshot, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
    

}
- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
///	firstLogin= NO;
	
	NSLog(@"SAVE PHOTO");
	// Unable to save the image
	if (error)
	{
		alert = [[UIAlertView alloc] initWithTitle:@"Error"
                                           message:@"Unable to save image to Photo Album."
                                          delegate:self cancelButtonTitle:@"Ok"
                                 otherButtonTitles:nil];
        [alert show];
        [alert release];
	}
    else //if([_session isConnected] == NO)
    {
		alert = [[UIAlertView alloc] initWithTitle:@"Success"
                                           message:@"Photo saved to Camera Roll in Photos App."
                                          delegate:self cancelButtonTitle:@"Ok"
                                 otherButtonTitles:nil];
        [alert show];
        [alert release];
        return;
    }
	
    
	/*else if([_session isConnected] == YES)
     {
     alerts = [[UIAlertView alloc] initWithTitle:@"Success"
     message:@"Do you want to upload to Facebook?"
     delegate:self cancelButtonTitle:@"YES"
     otherButtonTitles:@"NO",nil];
     
     [alerts show];
     [alerts release];
     }*/
    
    
    
}
- (IBAction)backBtnAction:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (IBAction)tweeterBtn:(id)sender {
    
    CGSize contextSize=CGSizeMake(320,427);
	UIGraphicsBeginImageContext(contextSize);
	[self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
	screenshot = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
    
    TWTweetComposeViewController *twitter = [[TWTweetComposeViewController alloc] init];
    NSString *sStatusMessage =@"You can more downloads from- http://www.ipooja.com/  or https://twitter.com/iPooja";
    [twitter setInitialText:sStatusMessage];
    [twitter addImage:screenshot];
    [self presentModalViewController:twitter animated:YES];

}

- (IBAction)fbBtn:(id)sender {
    
   // [self fbDidLogin];
    [fbObject initWithAppId:@"153384048205806" andDelegate:self];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"FBAccessTokenKey"]
        && [defaults objectForKey:@"FBExpirationDateKey"]) {
        fbObject.accessToken = [defaults objectForKey:@"FBAccessTokenKey"];
        fbObject.expirationDate = [defaults objectForKey:@"FBExpirationDateKey"];
    }
    
    if (![fbObject isSessionValid]) {
        
        
        //        NSMutableDictionary * params =
        //        [NSMutableDictionary dictionaryWithObjectsAndKeys:
        //         @"select birthday, name, uid, pic_square from user where uid in (select uid2 from friend where uid1=me()) order by name",
        //         @"query",
        //         nil];
        //
        //        [self.facebook requestWithMethodName: @"fql.query" andParams: params andHttpMethod: @"POST" andDelegate: self];
        
        
        NSArray *permissions = [[NSArray alloc] initWithObjects:
                                @"user_likes",
                                @"read_stream",@"publish_actions",
                                nil];
        [fbObject authorize:permissions];
        //
    }
    else if([fbObject isSessionValid])
    {
        [self fbDidLogin];
    }

}
#pragma mark- facebook method
- (void)fbDidLogin
{
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   @"iPooja Apps", @"name",
                                   screenshot, @"picture",
                                 
                                   nil];
    
    // Publish.
    // This is the most important method that you call. It does the actual job, the message posting.
    [fbObject requestWithGraphPath:@"me/feed" andParams:params andHttpMethod:@"POST" andDelegate:self];
    //    NSMutableDictionary* params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
    //                                   @"153384048205806", @"app_id",
    //                                   @"", @"link",
    //                                   @"http://i-softinc.com/devloper/project_images/icon@2x.png", @"picture",
    //                                   @"", @"name",
    //                                   @"", @"caption",
    //                                   @"", @"description",
    //                                   nil];
    //
    //
    //[fbObject dialog:@"feed" andParams:params andDelegate:self];
    
}
- (void)fbDidNotLogin:(BOOL)cancelled
{
}
- (void)fbDidExtendToken:(NSString*)accessToken
               expiresAt:(NSDate*)expiresAt
{
}
- (void)fbDidLogout{
}
- (void)fbSessionInvalidated{
}
#pragma mark FBRequest Delegate
- (void)requestLoading:(FBRequest *)request
{
}
- (void)request:(FBRequest *)request didReceiveResponse:(NSURLResponse *)response
{
    NSHTTPURLResponse *resp=(NSHTTPURLResponse *)response;
    if (resp.statusCode>=400)
    {
        [self request:request didFailWithError:[NSError errorWithDomain:@"400" code:400 userInfo:nil]];
    }
}
- (void)request:(FBRequest *)request didFailWithError:(NSError *)error
{
    
}
- (void)request:(FBRequest *)request didLoad:(id)result
{
    
}

@end
