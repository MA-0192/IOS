//
//  DiracAudioPlayerExampleViewController.h
//  DiracAudioPlayerExample
//
//  Created by Richa Kumar 10.04.2013
//  Copyright 2011 The DSP Dimension. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DiracAudioPlayer.h"
#import "Constants.h"
#import "GlobalValues.h"
#import "SharedData.h"

#import "DurationView.h"
#import <sqlite3.h>
#import "FMDatabase.h"

@interface DiracAudioPlayerExampleViewController : UIViewController <UIPickerViewDelegate,UIGestureRecognizerDelegate,UIActionSheetDelegate> {
    SharedData *shrdObj;
    DurationView *durationObj;
    NSTimer *timer;
    int ArrayIndexNunber;
    
    BOOL showDuration;
    UIView *durationView;
    IBOutlet UILabel *instrumentLbl;
	IBOutlet UIButton *uiStartButton;
	IBOutlet UIButton *uiStopButton;
	
	IBOutlet UISlider *uiDurationSlider;
	IBOutlet UISlider *uiPitchSlider;
	
	IBOutlet UILabel *uiDurationLabel;
	IBOutlet UILabel *uiPitchLabel;

	IBOutlet UISwitch *uiVarispeedSwitch;
	BOOL mUseVarispeed;

	DiracAudioPlayer *mDiracAudioPlayer;
    UIPickerView *myPickerView;
    UIPickerView *pickerView;
    NSMutableArray *CompleteArray,*taalsArray,*instrument_Array;
    int pickerSelection;
    IBOutlet UILabel *songName;
    
    NSString *AudioSelectedName,*AudioSelectedType;
     NSString *AudioSelectedName2,*AudioSelectedType2;
    UIView *toolView;
    
    IBOutlet UILabel *MaintaalsLbl;
    IBOutlet UIButton *stopBtn;
    int indexPicker;
    IBOutlet UIButton *playBtn;
    
    IBOutlet UILabel *subTaals;
    BOOL PlayerPlaying;
    UIActionSheet *actionSheet;
    
    
    NSString *MainCatName, *subCatName;
    
    NSMutableDictionary *MaintaalsDic,*MaintaalsDic_TEM;
    NSString *PickerType;
    BOOL mainpickerClicked,subpickerClicked;
    float sliderValue;
    
    
    
    AVAudioPlayer *bgPlayer ;
    UILabel *DurationLbl;
    NSTimer *stopWatchTimer; // Store the timer that fires after a certain time
    NSDate *startDate;
    // Stores the date of the click on the start button
    NSString *playingTimeString;

    
    int pitchIncrease;
}
@property (strong, nonatomic) NSTimer *stopWatchTimer; // Store the timer that fires after a certain time
@property (strong, nonatomic) NSDate *startDate;
- (IBAction)instrumentOpenPicker:(id)sender;
@property (retain, nonatomic) IBOutlet UIButton *pauseBtn;
- (IBAction)pauseBtnAction:(id)sender;
- (IBAction)subTaalsOpenPicker:(id)sender;
- (IBAction)MainTaalsOpenPicker:(id)sender;
@property (retain, nonatomic) IBOutlet UIButton *instrumentpenPicker;

- (IBAction)openAudioList:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnTempoIncreaseByOne;
@property (strong, nonatomic) IBOutlet UIButton *btnTempoIncreaseByTen;
@property (strong, nonatomic) IBOutlet UIButton *btnTempoDecreaseByOne;
@property (strong, nonatomic) IBOutlet UIButton *btnTempoDecreaseByTen;
@property (strong, nonatomic) IBOutlet UILabel *lblShowBPM;

@property (strong, nonatomic) IBOutlet UIButton *btnPitchIncrease;
@property (strong, nonatomic) IBOutlet UIButton *btnPitchDecrease;
- (IBAction)audio2Action:(id)sender;
- (IBAction)audio1Action:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *lblShowPitchNode;

@property (strong,nonatomic) IBOutlet UISegmentedControl *segmentContolForChangingAudio;

@property (strong, nonatomic) NSArray *arrPitchNodes;
@property (strong, nonatomic) NSString *strPitchNodes;
@property (strong, nonatomic) NSArray *arrTemp;

@property (strong, nonatomic) NSTimer *timer;

-(IBAction)uiDurationSliderMoved:(UISlider *)sender;
-(IBAction)uiPitchSliderMoved:(UISlider *)sender;

-(IBAction)uiStartButtonTapped:(UIButton *)sender;
-(IBAction)uiStopButtonTapped:(UIButton *)sender;

-(IBAction)uiVarispeedSwitchTapped:(UISwitch *)sender;

-(IBAction)btnTempoIncreaseByOneClicked;
-(IBAction)btnTempoIncreaseByTenClicked;
-(IBAction)btnTempoDecreaseByOneClicked;
-(IBAction)btnTempoDecreaseByTenClicked;

-(IBAction)btnPitchIncreaseClicked;
-(IBAction)btnPitchDecreaseClicked;

-(IBAction)btnSegmentControlClicked;

- (IBAction)addPresetsBtn:(id)sender;
//-(void) tempoIncrease;
//-(void) tempoDecrease;


@end

