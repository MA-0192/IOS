//
//  InfoViewController.m
//  DiracAudioPlayerExample
//
//  Created by Vivek Yadav on 11/19/13.
//
//

#import "InfoViewController.h"

@interface InfoViewController ()

@end

@implementation InfoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Info", @"Info");
     //    self.tabBarItem.image = [UIImage imageNamed:@"myplan.png"];
        self.tabBarItem.title=@"Info";
        
        [  self.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                   [UIColor whiteColor], UITextAttributeTextColor,
                                                   [NSValue valueWithUIOffset:UIOffsetMake(0,0)], UITextAttributeTextShadowOffset,
                                                   [UIFont boldSystemFontOfSize:12], UITextAttributeFont, nil]
                                         forState:UIControlStateNormal];
        
        
        [self.tabBarItem setFinishedSelectedImage:[UIImage imageNamed:@"myplan.png"] withFinishedUnselectedImage:[UIImage imageNamed:@"myplan.png"]];
        

        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
