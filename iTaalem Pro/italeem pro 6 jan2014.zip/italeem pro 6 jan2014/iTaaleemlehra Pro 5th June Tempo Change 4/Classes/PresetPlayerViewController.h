//
//  PresetPlayerViewController.h
//  DiracAudioPlayerExample
//
//  Created by Vivek Yadav on 11/20/13.
//
//

#import <UIKit/UIKit.h>
#import "DiracAudioPlayer.h"
#import "FMDatabase.h"
@interface PresetPlayerViewController : UIViewController
{
    
    IBOutlet UILabel *PitchLbl;
    IBOutlet UILabel *TempoLbl;
    IBOutlet UILabel *InstrumentLbl;
    IBOutlet UILabel *SubTaalLbl;
    IBOutlet UILabel *MainTaalLbl;
    IBOutlet UIButton *playBtn;
    
    DiracAudioPlayer *mDiracAudioPlayer;
    int indexValue,pitchIncrease;
    float tempoIncrese,tempoFinal;
    NSArray * Pitcharr;
    
    
    
    __weak IBOutlet UIButton *previousBtn;
    __weak IBOutlet UIButton *nextBtn;
    
    
    
}
- (IBAction)tempoDownTen:(id)sender;
- (IBAction)tempoUpTen:(id)sender;
- (IBAction)tempoUPAction:(id)sender;
- (IBAction)playBtnAction:(id)sender;
- (IBAction)pauseBtnAction:(id)sender;
- (IBAction)previousBtnAction:(id)sender;
- (IBAction)nextBtnAction:(id)sender;
- (IBAction)stopBtnAction:(id)sender;
- (IBAction)TempoDownAction:(id)sender;
- (IBAction)pitchUpAction:(id)sender;
- (IBAction)pitchDownAction:(id)sender;

@property (strong, nonatomic) NSMutableArray *dic;
@property (strong, nonatomic) NSString *indexNumber;
@property (strong, nonatomic) NSString *MainIndexNumber;
@end
