//
//  PresetsViewController.h
//  DiracAudioPlayerExample
//
//  Created by Vivek Yadav on 11/19/13.
//
//

#import <UIKit/UIKit.h>
#import "SharedData.h"
#import <sqlite3.h>

#import "FMDatabase.h"
@interface PresetsViewController : UIViewController<UIGestureRecognizerDelegate>

{
    IBOutlet UITableView *tableview;
    NSIndexPath *indexPath_gesture;
    SharedData *shrdObj;
 //   NSMutableDictionary *dic;
    NSMutableArray *commonarray;
    
  //  UIBarButtonItem* addBtn;
    UIBarButtonItem *EditBtn;
  //   NSString *databasePath;
    
}
@end
