//
//  SharedData.h
//  singletonClassDemo
//
//  Created by Vivek Yadav on 11/13/13.
//  Copyright (c) 2013 Mediaagility. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SharedData : NSObject
@property(nonatomic, strong) NSString * globalObject;
@property(nonatomic, strong) NSString * Tempo;
@property(nonatomic, strong) NSString * pitch;
@property(nonatomic, strong) NSString * pitch_value;
@property(nonatomic, strong) NSString * MainCat;
@property(nonatomic, strong) NSString * SubCat;
@property(nonatomic, strong) NSString * InstrumentCat;
@property(nonatomic, strong) NSString * arrayIndex;


@property(nonatomic, strong) NSString * audioName1;
@property(nonatomic, strong) NSString * audioType1;
@property(nonatomic, strong) NSString * audioName2;
@property(nonatomic, strong) NSString * audioType2;
@property(nonatomic, strong) NSString * tempo_value;

+(SharedData *)sharedObj;
@end
