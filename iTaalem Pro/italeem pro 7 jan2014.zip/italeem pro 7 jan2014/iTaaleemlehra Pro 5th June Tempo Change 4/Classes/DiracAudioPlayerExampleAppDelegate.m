//
//  DiracAudioPlayerExampleAppDelegate.m
//  DiracAudioPlayerExample
//
//  Created by Stephan on 20.03.11.
//  Copyright 2011 The DSP Dimension. All rights reserved.
//

#import "DiracAudioPlayerExampleAppDelegate.h"
#import "DiracAudioPlayerExampleViewController.h"
#import "Constants.h"
#import "PresetsViewController.h"
#import "InfoViewController.h"
#import "SettingsViewController.h"
@implementation DiracAudioPlayerExampleAppDelegate

@synthesize window;
@synthesize viewController;
@synthesize navigationController;
GlobalValues *globalValues;

#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {    
    
    
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"LockScreen"] isEqualToString:@"on"]) {
            [[UIApplication sharedApplication] setIdleTimerDisabled: YES];
    }else
    {
        [[UIApplication sharedApplication] setIdleTimerDisabled: NO];
    }
       [[UIApplication sharedApplication] keyWindow].tintColor = [UIColor blackColor];
 //   self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
  //  Override point for customization after application launch.
 

    UIViewController *viewController2;
    UIViewController *viewController3;
    UIViewController *viewController4;
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        viewController1 = [[DiracAudioPlayerExampleViewController alloc] initWithNibName:@"DiracAudioPlayerExampleViewController_iPad" bundle:nil] ;
        viewController2 = [[PresetsViewController alloc] initWithNibName:@"PresetsViewController_iPad" bundle:nil] ;
        
        viewController3 = [[SettingsViewController alloc] initWithNibName:@"SettingsViewController_iPad" bundle:nil] ;
        
        viewController4= [[InfoViewController alloc] initWithNibName:@"InfoViewController_iPad" bundle:nil] ;

    }else
    {
    if ([UIScreen mainScreen].bounds.size.height==480) {
        viewController1 = [[DiracAudioPlayerExampleViewController alloc] initWithNibName:@"DiracAudioPlayerExampleViewController" bundle:nil];
        viewController2 = [[PresetsViewController alloc] initWithNibName:@"PresetsViewController" bundle:nil] ;
        
        viewController3 = [[SettingsViewController alloc] initWithNibName:@"SettingsViewController" bundle:nil] ;
        
        viewController4= [[InfoViewController alloc] initWithNibName:@"InfoViewController" bundle:nil] ;
    }else
    {
        viewController1 = [[DiracAudioPlayerExampleViewController alloc] initWithNibName:@"DiracAudioPlayerExampleViewController_iPod" bundle:nil];
        viewController2 = [[PresetsViewController alloc] initWithNibName:@"PresetsViewController_iPod" bundle:nil] ;
        
        viewController3 = [[SettingsViewController alloc] initWithNibName:@"SettingsViewController_iPod" bundle:nil] ;
        
        viewController4= [[InfoViewController alloc] initWithNibName:@"InfoViewController_iPod" bundle:nil] ;
    }
    }
    
 
    
    self.tabBarController = [[UITabBarController alloc] init];
    self.tabBarController.delegate = self;
    self.tabBarController.viewControllers = @[[[UINavigationController alloc] initWithRootViewController:viewController1] , [[UINavigationController alloc] initWithRootViewController:viewController2] ,[[UINavigationController alloc] initWithRootViewController:viewController3] ,[[UINavigationController alloc] initWithRootViewController:viewController4] ];
    self.tabBarController.navigationController.navigationBar.hidden=YES;
    self.window.rootViewController = self.tabBarController;
    
    
    BOOL isAtLeast7 = [[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0;
    
    if ( isAtLeast7 ) {
        [self.tabBarController.tabBar setTranslucent:NO];
        [[UITabBar appearance] setBarTintColor:[UIColor colorWithRed:20/255 green:20/255 blue:20/255 alpha:1]];
        [[UITabBar appearance] setTintColor:[UIColor colorWithRed:20/255 green:20/255 blue:204/255.0 alpha:1]];
    }
    
    
    [self.window makeKeyAndVisible];
    [self createCopyOfDatabaseIfNeeded];
    
    
    [[UIApplication sharedApplication]
     registerForRemoteNotificationTypes: (UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeBadge |
                                          UIRemoteNotificationTypeSound)];
    
    [self clearNotifications];
    
    return YES;
}
-(void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    NSString *devToken = [[[[deviceToken description]
                            stringByReplacingOccurrencesOfString:@"<"withString:@""]
                           stringByReplacingOccurrencesOfString:@">" withString:@""]
                          stringByReplacingOccurrencesOfString: @" " withString: @""];
    
    NSString *str = [NSString
                     stringWithFormat:@"%@",devToken];
    [[NSUserDefaults standardUserDefaults]setObject:str forKey:@"device_token"];
    
    
    
    
    NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[[NSString stringWithFormat:@"http://notifications.ipooja.com/iPoojaNotifier/devicetokenupdate?platform=ios&appid=17&token=%@&dev=dev",str] stringByReplacingOccurrencesOfString:@" " withString:@"%20"]]];
    
    
    
    
    NSURLConnection  *connectionPost  = [[NSURLConnection alloc] initWithRequest:theRequest delegate:nil] ;
    connectionPost=nil;
    
    NSLog(@"%@",[[NSString stringWithFormat:@"http://notifications.ipooja.com/iPoojaNotifier/devicetokenupdate?platform=ios&appid=17&token=%@&dev=dev",str] stringByReplacingOccurrencesOfString:@" " withString:@"%20"]);
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo{
    // Place your code for what to do when the ios device receives notification
    NSLog(@"The user info: %@", userInfo);
    
    
    if ([[NSUserDefaults standardUserDefaults] objectForKey:@"badges"])
    {
        [[UIApplication sharedApplication] setApplicationIconBadgeNumber:[[[NSUserDefaults standardUserDefaults] objectForKey:@"badges"] integerValue]+1];
    }else
    {
        [[UIApplication sharedApplication] setApplicationIconBadgeNumber:1];
        [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:@"badges"];
    }
    
    
    
    
    
    
    //    [[NSUserDefaults standardUserDefaults]setObject:[[userInfo objectForKey:@"aps"]objectForKey:@"badge"] forKey:@"badge"];
}
- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification {
    [UIApplication sharedApplication].applicationIconBadgeNumber=application.applicationIconBadgeNumber;
}

- (void) clearNotifications {
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber: 0];
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
}
- (void)application:(UIApplication *) didFailToRegisterForRemoteNotificationsWithError:(NSError *)err {
    // Place your code for what to do when the registration fails
    NSLog(@"Registration Error: %@", err);
}


- (void)createCopyOfDatabaseIfNeeded {
    // First, test for existence.
    BOOL success;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *writableDBPath = [documentsDirectory stringByAppendingPathComponent:@"italeemPresets.sqlite"];
    success = [fileManager fileExistsAtPath:writableDBPath];
    if (success)
        return;
    // The writable database does not exist, so copy the default to the appropriate location.
    NSString *defaultDBPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"italeemPresets.sqlite"];
    success = [fileManager copyItemAtPath:defaultDBPath toPath:writableDBPath error:&error];
    if (!success) {
        NSAssert1(0, @"Failed to create writable database file with message '%@'.", [error localizedDescription]);
    }
}


- (void)applicationWillResignActive:(UIApplication *)application {
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, called instead of applicationWillTerminate: when the user quits.
     */
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    /*
     Called as part of  transition from the background to the inactive state: here you can undo many of the changes made on entering the background.
     */
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}


- (void)applicationWillTerminate:(UIApplication *)application {
    /*
     Called when the application is about to terminate.
     See also applicationDidEnterBackground:.
     */
}


#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    /*
     Free up as much memory as possible by purging cached data objects that can be recreated (or reloaded from disk) later.
     */
}





@end
