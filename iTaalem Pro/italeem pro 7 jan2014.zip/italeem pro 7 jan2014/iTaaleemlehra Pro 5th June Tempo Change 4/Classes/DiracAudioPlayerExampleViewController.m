
/*
 
	ABSTRACT:
	This example demonstrates how to use the DiracAudioFile player to process and play back
	an audio file in real time (high quality setting)
 
 */

//
//  DiracAudioPlayerExampleViewController.m
//  DiracAudioPlayerExample
//
//  Created by Stephan on 20.03.11.
//  Copyright 2011 The DSP Dimension. All rights reserved.
//
#import "DiracAudioPlayerExampleViewController.h"
#import <QuartzCore/QuartzCore.h>
@implementation DiracAudioPlayerExampleViewController
@synthesize btnTempoIncreaseByOne = _btnTempoIncreaseByOne;
@synthesize btnTempoIncreaseByTen = _btnTempoIncreaseByTen;
@synthesize btnTempoDecreaseByOne = _btnTempoDecreaseByOne;
@synthesize btnTempoDecreaseByTen = _btnTempoDecreaseByTen;
@synthesize lblShowBPM = _lblShowBPM;
@synthesize btnPitchIncrease = _btnPitchIncrease;
@synthesize btnPitchDecrease = _btnPitchDecrease;
@synthesize lblShowPitchNode = _lblShowPitchNode;
@synthesize arrPitchNodes = _arrPitchNodes;
@synthesize strPitchNodes = _strPitchNodes;
@synthesize arrTemp = _arrTemp;
@synthesize timer = _timer;

@synthesize segmentContolForChangingAudio = _segmentContolForChangingAudio;

float previousValue = 0.0;
float currentValue = 0.0;

int BPMValue = 100;
int LoadedAudio = 1;
int count = 0;
BOOL boolDecrement;
//BOOL boolLongSinglePress;
BOOL boolLimitReached = NO;

- (void)diracPlayerDidFinishPlaying:(DiracAudioPlayerBase *)player successfully:(BOOL)flag
{
	NSLog(@"Dirac player instance (0x%lx) is done playing", (long)player);
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Home", @"Home");
    //    self.tabBarItem.image = [UIImage imageNamed:@"home.png"];
        self.tabBarItem.title=@"Home";
        
        
        
        [  self.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                   [UIColor whiteColor], UITextAttributeTextColor,
                                                   [NSValue valueWithUIOffset:UIOffsetMake(0,0)], UITextAttributeTextShadowOffset,
                                                   [UIFont boldSystemFontOfSize:12], UITextAttributeFont, nil]
                                         forState:UIControlStateNormal];
        
        
        [self.tabBarItem setFinishedSelectedImage:[UIImage imageNamed:@"home.png"] withFinishedUnselectedImage:[UIImage imageNamed:@"home.png"]];
        
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
//    durationObj.frame=self.view.bounds;
//    [self. addSubview:durationObj];
    
//    self.view.backgroundColor=[UIColor redColor];

  

//    if (showDuration==NO) {
//        double delayInSeconds = 2.0;
//        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
//        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            //code to be executed on the main queue after delay
   
//            showDuration=YES;
//        });
//
//    }

}

#pragma mark- timer method

-(void)handleTimer
{
    [durationView removeFromSuperview];
    durationView=Nil;
//
    durationView=[[UIView alloc]initWithFrame:self.view.bounds];
    durationView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Blue.png"]];
    [self.view addSubview:durationView];
    
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleTap)];
    [durationView addGestureRecognizer:singleTap];
   
    UIImageView *bgimageView=[[UIImageView alloc]init];
    bgimageView.backgroundColor=[UIColor whiteColor];
    bgimageView.alpha=0.1;
    [durationView addSubview:bgimageView];
    
    
    
    UILabel *mainTaalLbl=[[UILabel alloc]init];
    mainTaalLbl.text=MaintaalsLbl.text;
    mainTaalLbl.font=[UIFont boldSystemFontOfSize:24];
    mainTaalLbl.textAlignment=NSTextAlignmentCenter;
    mainTaalLbl.textColor=[UIColor whiteColor];
 //   mainTaalLbl.backgroundColor=[UIColor redColor];
    
    [durationView addSubview:mainTaalLbl];
    
    UILabel *SubTaalLbl=[[UILabel alloc]init];
    SubTaalLbl.text=songName.text;
    SubTaalLbl.textColor=[UIColor whiteColor];
      SubTaalLbl.textAlignment=NSTextAlignmentCenter;
 //     SubTaalLbl.backgroundColor=[UIColor redColor];
    [durationView addSubview:SubTaalLbl];
    
    UILabel *InstrumentLbl=[[UILabel alloc]init];
    InstrumentLbl.text=SubTaalLbl.text;
    InstrumentLbl.textColor=[UIColor whiteColor];
      InstrumentLbl.textAlignment=NSTextAlignmentCenter;
    [durationView addSubview:InstrumentLbl];
   //    InstrumentLbl.backgroundColor=[UIColor redColor];
    
    DurationLbl=[[UILabel alloc]init];
    DurationLbl.text=playingTimeString;
    DurationLbl.font=[UIFont boldSystemFontOfSize:20];
      DurationLbl.textAlignment=NSTextAlignmentCenter;
    [durationView addSubview:DurationLbl];
    DurationLbl.backgroundColor=[UIColor clearColor];
    DurationLbl.layer.cornerRadius = 8;
    DurationLbl.layer.borderColor=[UIColor whiteColor].CGColor;
    DurationLbl.layer.borderWidth = 2.0;
    DurationLbl.textColor=[UIColor whiteColor];
//    DurationLbl.backgroundColor=[UIColor redColor];
    
    
    UILabel *Tempo=[[UILabel alloc]init];
    Tempo.text=[NSString stringWithFormat:@"%@ Bpm", self.lblShowBPM.text ];
      Tempo.textAlignment=NSTextAlignmentLeft;
    [durationView addSubview:Tempo];
      Tempo.textColor=[UIColor whiteColor];
    
    
    UILabel *Pitch=[[UILabel alloc]init];
    Pitch.text=self.lblShowPitchNode.text;
      Pitch.textAlignment=NSTextAlignmentRight;
    [durationView addSubview:Pitch];
    Pitch.font=[UIFont boldSystemFontOfSize:24];
      Pitch.textColor=[UIColor whiteColor];
    
    bgimageView.frame=CGRectMake(20, 70, 280, 360) ;
    mainTaalLbl.frame=CGRectMake(65, 97, 190, 33) ;
    SubTaalLbl.frame=CGRectMake(65, 147, 190, 33) ;
    InstrumentLbl.frame=CGRectMake(65, 200, 190, 33) ;
    DurationLbl.frame=CGRectMake(86, 283, 150, 33) ;
    Tempo.frame=CGRectMake(40, 356, 113, 50) ;
    Pitch.frame=CGRectMake(190, 356, 95, 50) ;
    
    
    [UIView beginAnimations:nil context:nil/*contextPoint*/];
    DurationLbl.transform = CGAffineTransformMakeScale(1.5, 1.5); //increase the size by 2
    //etc etc same procedure for the other labels.
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDelay:0.1];
    [UIView setAnimationDuration:1];
    [UIView setAnimationRepeatCount:1];
    [UIView setAnimationCurve:UIViewAnimationCurveLinear];
    [UIView commitAnimations];

}
-(void)handleSingleTap
{
    
    
//    [UIView beginAnimations:nil context:NULL];
//    [UIView setAnimationDuration:1];
//    [durationView setAlpha:0];
    [durationView removeFromSuperview];

//    [UIView commitAnimations];
    
}
- (void)viewDidLoad
{
    [super viewDidLoad];

    pitchIncrease=0;
[[NSNotificationCenter defaultCenter] addObserver:self   selector:@selector(Playpresets:) name:@"Playpresets" object:nil];

 //   [[NSBundle mainBundle] loadNibNamed:@"DiracAudioPlayerExampleViewController" owner:self options:nil];
    
//    NSString *soundFilePath = [[NSBundle mainBundle] pathForResource:@"backgroundAudio" ofType:@"mp3"];
//    NSURL *soundFileURL = [NSURL fileURLWithPath:soundFilePath];
//    
//    bgPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:soundFileURL error:nil];
//    bgPlayer.numberOfLoops = -1; //Infinite
//    
//    
//    NSLog(@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"BackgroundAudio"]);
//    
//    if ( [[[NSUserDefaults standardUserDefaults] objectForKey:@"BackgroundAudio"] isEqualToString:@"on"]) {
//    
//        [bgPlayer play];
//    }else
//    {
//        [bgPlayer stop];
//    }
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(BackgroundAudioNotification:)
//                                                 name:@"BackgroundAudio"
//                                               object:nil];

    
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(StopAudioNotification:)
                                                 name:@"StopAudio"
                                               object:nil];
    
    [[UITabBarItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor orangeColor], UITextAttributeTextColor, nil]
                                             forState:UIControlStateNormal];
    
    
    
//     timer=    [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(handleTimer) userInfo:nil repeats:YES];
//    if ( [[[NSUserDefaults standardUserDefaults] objectForKey:@"DisplayAudio"] isEqualToString:@"on"]) {
//        
//        if (timer == nil)
//        {
//            timer = [NSTimer scheduledTimerWithTimeInterval:30
//                                                      target:self
//                                                    selector:@selector(handleTimer)
//                                                    userInfo:nil
//                                                     repeats:YES];
//        }
//    }else
//    {
//        if (timer != nil)
//        {
//            [timer invalidate];
//            timer = nil;
//        }
//    }
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(DisplayAudioNotification:)
//                                                 name:@"DisplayAudio"
//                                               object:nil];
//    
//    
    
    
    
    

    self.navigationController.navigationBar.hidden=YES;
    
    PickerType=@"maintaals";
    if([[UIScreen mainScreen] bounds].size.height == 480)
    {
          self.view.frame=CGRectMake(0, 0, 320, 480);
    }else
    {
          self.view.frame=CGRectMake(0, 0, 320, 568);
    }
    
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame = self.view.bounds;
    gradient.colors = @[(id)[[UIColor lightGrayColor] CGColor],
                        (id)[[UIColor whiteColor] CGColor]];
    [self.view.layer insertSublayer:gradient atIndex:0];

    taalsArray =[[NSMutableArray alloc]initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"taals" ofType:@"plist"]];
    NSLog(@"%@",taalsArray );
    NSLog(@"%@",[[[taalsArray objectAtIndex:0] allKeys] objectAtIndex:1]);
    NSLog(@"%@",[[taalsArray objectAtIndex:0] allKeys] );
    NSLog(@"%@",[[taalsArray objectAtIndex:0] objectForKey:[[[taalsArray objectAtIndex:0] allKeys] objectAtIndex:1]]);
    
   
    CompleteArray =[[NSMutableArray alloc]initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[[taalsArray objectAtIndex:0] objectForKey:[[[taalsArray objectAtIndex:0] allKeys] objectAtIndex:1]] ofType:@"plist"]];
    
    MainCatName=[[taalsArray objectAtIndex:0] objectForKey:[[[taalsArray objectAtIndex:0] allKeys] objectAtIndex:1]];


    mUseVarispeed = NO;
    playBtn.hidden=NO;
    self.pauseBtn.hidden=YES;
    PlayerPlaying=NO;
    self.lblShowBPM.text = [NSString stringWithFormat:@"%d",BPMValue];
    
    boolDecrement = TRUE;
    self.arrPitchNodes = [[NSArray alloc]initWithObjects:@"C",@"C#",@"D",@"D#",@"E",@"F",@"F#",@"G", @"G#", @"A",@"A#",@"B",nil];
    self.lblShowPitchNode.text=[self.arrPitchNodes objectAtIndex:0];
    
    
    [self firstTymAudioLoad];
    
    //    display playing time

        double delayInSeconds = 0;
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
                dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
  
    startDate = [NSDate date] ;

  stopWatchTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(updateTimer) userInfo:nil repeats:YES];
                    
                 });
    
   }

#pragma mark- display playing time timer
- (void)updateTimer
{
    
    
    NSLog(@"%f",stopWatchTimer.timeInterval);


    NSDate *currentDate = [NSDate date];
    NSTimeInterval timeInterval = [currentDate timeIntervalSinceDate:startDate];
    NSDate *timerDate = [NSDate dateWithTimeIntervalSince1970:timeInterval];
    
    // Create a date formatter
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"HH:mm:ss"];
    [dateFormatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0.0]];
    
    DurationLbl.text=[dateFormatter stringFromDate:timerDate];
    
    playingTimeString=[dateFormatter stringFromDate:timerDate];
}

#pragma mark- first tym audio load
-(void)firstTymAudioLoad
{
    [MaintaalsDic removeAllObjects];
    MaintaalsDic=nil;
    
    
    MaintaalsDic =[[NSMutableDictionary alloc]initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Maintaals" ofType:@"plist"]];
    
    NSLog(@"%@",[[MaintaalsDic allKeys] objectAtIndex:0]);
    NSLog(@"%d",MaintaalsDic.count );
    
    
    MaintaalsLbl.text=[[MaintaalsDic allKeys] objectAtIndex:0];
    
    [CompleteArray removeAllObjects];
    CompleteArray=Nil;
    CompleteArray =[[NSMutableArray alloc]initWithArray:[[MaintaalsDic objectForKey:[[MaintaalsDic allKeys] objectAtIndex:0]] allKeys]];
    

    songName.text=[CompleteArray objectAtIndex:0];
    NSLog(@"%@",CompleteArray);
    
    instrument_Array =[[NSMutableArray alloc]initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[[MaintaalsDic objectForKey:[[MaintaalsDic allKeys] objectAtIndex:0]] objectForKey:[CompleteArray objectAtIndex:0]] ofType:@"plist"]];
    NSLog(@"instrument_Array----->%@",instrument_Array);
    
    
    PickerType=@"instrument";
    mainpickerClicked=YES ;
    subpickerClicked=YES;
    
    subTaals.text=[[instrument_Array objectAtIndex:0] objectForKey:@"Name"];
    AudioSelectedName=[[instrument_Array objectAtIndex:0] objectForKey:@"Audio1"];
    AudioSelectedType=[[instrument_Array objectAtIndex:0] objectForKey:@"Audio1_Type"];
    NSLog(@"%@",AudioSelectedName);
    
    
    AudioSelectedName2=[[instrument_Array objectAtIndex:0] objectForKey:@"Audio2"];
    AudioSelectedType2=[[instrument_Array objectAtIndex:0] objectForKey:@"Audio2_Type"];
    
    NSLog(@"%@",AudioSelectedName);
    
    NSString *inputSound ;
    
    if ([self.lblShowBPM.text integerValue]<200) {
        inputSound  = [[NSBundle mainBundle] pathForResource:  AudioSelectedName ofType:AudioSelectedType];
    }else
    {
        inputSound  = [[NSBundle mainBundle] pathForResource:  AudioSelectedName2 ofType:AudioSelectedType2];
    }
    
    NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
    
    NSError *error = nil;
    mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];
    [mDiracAudioPlayer setDelegate:self];
    [mDiracAudioPlayer setNumberOfLoops:-1];
    
    mUseVarispeed = NO;
//    [mDiracAudioPlayer play];
    
    
    NSLog(@"%f",uiDurationSlider.value);
    sliderValue=1;
    
//    self.pauseBtn.hidden=NO;
//    playBtn.hidden=YES;
//    [mDiracAudioPlayer play];
}
-(void)viewWillDisappear:(BOOL)animated
{

 //   shrdObj.globalObject=@"test";
 //   NSLog(@"%@", shrdObj.globalObject);
}
-(IBAction)uiDurationSliderMoved:(UISlider *)sender;
{
    
    NSLog(@"%f",1/sender.value);
    sliderValue=sender.value;
  //  if (PlayerPlaying==YES) {
    
    
	[mDiracAudioPlayer changeDuration: 1/(sender.value)];
	uiDurationLabel.text = [NSString stringWithFormat:@"%3.2f", sender.value];
    
	
//	if (mUseVarispeed) {
//		float val = 1.f/sender.value;
//		uiPitchSlider.value = (int)12.f*log2f(val);
//		uiPitchLabel.text = [NSString stringWithFormat:@"%d", (int)uiPitchSlider.value];
//		[mDiracAudioPlayer changePitch:val];
//	}
 
    BPMValue = (uiDurationSlider.value) * 100;
    self.lblShowBPM.text = [NSString stringWithFormat:@"%d",BPMValue];
    
    if(BPMValue >=200)
    {
        
        if (LoadedAudio==1) {
            [mDiracAudioPlayer stop];
            mDiracAudioPlayer=nil;
            
            NSString *inputSound  = [[NSBundle mainBundle] pathForResource:AudioSelectedName2 ofType:AudioSelectedType2];
            NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
            
            NSError *error = nil;
            
            if(mDiracAudioPlayer)
                mDiracAudioPlayer = nil;
            
            mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
            [mDiracAudioPlayer setDelegate:self];
            mDiracAudioPlayer.numberOfLoops = -1;
            
            
            if (PlayerPlaying==YES) {
                    [mDiracAudioPlayer play];
            }
            
        
            
            
            LoadedAudio=2;

        }
    }
    else if(BPMValue <200)
    {
        if (LoadedAudio==2) {
            [mDiracAudioPlayer stop];
            mDiracAudioPlayer=nil;
            
            NSString *inputSound  = [[NSBundle mainBundle] pathForResource: AudioSelectedName ofType: AudioSelectedType];
            NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
            
            NSError *error = nil;
            
            if(mDiracAudioPlayer)
                mDiracAudioPlayer = nil;
            
            mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
            [mDiracAudioPlayer setDelegate:self];
            mDiracAudioPlayer.numberOfLoops = -1;
            
            
            if (PlayerPlaying==YES) {
                [mDiracAudioPlayer play];
            }

            
          
            LoadedAudio=1;

        }
    }
    
    
    [mDiracAudioPlayer changePitch:powf(2.f, pitchIncrease / 12.f)];
    
//    }else {
//    	[uiDurationSlider setValue: 1];
//    }
}
-(IBAction)uiPitchSliderMoved:(UISlider *)sender;
{
	[mDiracAudioPlayer changePitch:powf(2.f, (int)sender.value / 12.f)];
	uiPitchLabel.text = [NSString stringWithFormat:@"%d", (int)sender.value];
    
}
-(IBAction)uiStartButtonTapped:(UIButton *)sender;
{
    if (AudioSelectedName) {
        [mDiracAudioPlayer play];
        mDiracAudioPlayer.numberOfLoops = -1;
        
        [mDiracAudioPlayer changePitch:powf(2.f, pitchIncrease / 12.f)];
     //   [playBtn setBackgroundImage:[UIImage imageNamed:@"pause"] forState:UIControlStateNormal];
        self.pauseBtn.hidden=NO;
        playBtn.hidden=YES;
         PlayerPlaying=YES;
        
        
        
        
        [stopWatchTimer invalidate];
        stopWatchTimer=Nil;
        startDate=nil;
        double delayInSeconds = 0;
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            
            startDate = [NSDate date]  ;
            
            stopWatchTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(updateTimer) userInfo:nil repeats:YES];
            
            
        });
        
    }else
    {
         PlayerPlaying=NO;
        playBtn.hidden=NO;
         self.pauseBtn.hidden=YES;
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:Nil message:@"Please select audio" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];
        alert=nil;
    }
    
    if ([PickerType isEqualToString:@"maintaals"] || [PickerType isEqualToString:@"subtaal"])
    {
        playBtn.hidden=NO;
        self.pauseBtn.hidden=YES;
    }
   
  //  }
}
- (IBAction)pauseBtnAction:(id)sender {
    
    playBtn.hidden=NO;
    self.pauseBtn.hidden=YES;
     [mDiracAudioPlayer pause];
    PlayerPlaying=NO;
}

- (IBAction)subTaalsOpenPicker:(id)sender {
    
}

- (IBAction)MainTaalsOpenPicker:(id)sender {
    
 
    PickerType=@"maintaals";
    [MaintaalsDic removeAllObjects];
    MaintaalsDic=nil;
    
    
    MaintaalsDic =[[NSMutableDictionary alloc]initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Maintaals" ofType:@"plist"]];
   
    NSLog(@"%@",MaintaalsDic );
    NSLog(@"%d",MaintaalsDic.count );
    
    
    //   [actionSheet removeFromSuperview];
    
    actionSheet = [[UIActionSheet alloc]initWithTitle:@"Please select audio" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:nil] ;
    [actionSheet showInView:self.view];
    actionSheet.backgroundColor=[UIColor whiteColor];
    [actionSheet setBounds:CGRectMake(0, 0, 320, 350)];
    
  pickerView = [[UIPickerView alloc]initWithFrame:CGRectMake(0, 40, 320, 140)];
    pickerView.delegate = self;
    // pickerView.dataSource = self;
    pickerView.showsSelectionIndicator = YES;
    
    
    UITapGestureRecognizer* gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pickerViewTapGestureRecognized:)];
    gestureRecognizer.cancelsTouchesInView = NO;
    [pickerView addGestureRecognizer:gestureRecognizer];
    
    UIToolbar *pickerToolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
    pickerToolbar.barStyle = UIBarStyleBlack;
    [pickerToolbar sizeToFit];
    
    
    UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStyleBordered target:self action:@selector(cancelButtonClicked)];
    
    cancelButton.tintColor=[UIColor whiteColor];
    
    UIBarButtonItem *flex = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil] ;
    
    flex.title=@"Please select audio";
    
//    UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(pickerDoneClicked)] ;
//     doneButton.tintColor=[UIColor whiteColor];
    
    
    [pickerToolbar setItems:[NSArray arrayWithObjects:cancelButton,flex,nil]];
    [actionSheet addSubview:pickerToolbar];
    [actionSheet addSubview:pickerView];
    
    pickerSelection=0;
    
}


	
// ---------------------------------------------------------------------------------------------------------------------------------------------

#pragma mark- play/pause /stop methods

-(void)pauseCustom
{
   
}
-(void)stopCustom
{
   }
-(IBAction)uiStopButtonTapped:(UIButton *)sender;
{
    PlayerPlaying=NO;
    playBtn.hidden=NO;
    self.pauseBtn.hidden=YES;
	[mDiracAudioPlayer stop];
    
    [playBtn setBackgroundImage:[UIImage imageNamed:@"play.png"] forState:UIControlStateNormal];
   
    
    
    [stopWatchTimer invalidate];
    stopWatchTimer=Nil;
    startDate=nil;

    
}
// ---------------------------------------------------------------------------------------------------------------------------------------------

-(IBAction)uiVarispeedSwitchTapped:(UISwitch *)sender;
{
	if (sender.on) {
		mUseVarispeed = YES;

		uiPitchSlider.enabled=NO;

		float val = 1.f/uiDurationSlider.value;
		uiPitchSlider.value = (int)12.f*log2f(val);
		uiPitchLabel.text = [NSString stringWithFormat:@"%d", (int)uiPitchSlider.value];
		[mDiracAudioPlayer changePitch:val];		
		
	} else {
		mUseVarispeed = NO;
		uiPitchSlider.enabled=YES;
	}
}


-(IBAction)btnTempoIncreaseByOneClicked
{
    
    if (PlayerPlaying==YES) {

    
    playBtn.hidden=YES;
    self.pauseBtn.hidden=NO;
    [mDiracAudioPlayer play];
    
    
    
    float tempoIncrease = (uiDurationSlider.value) + 0.01;
   
    sliderValue=tempoIncrease;
    NSLog(@"%F",uiDurationSlider.value);
    NSLog(@"%F",sliderValue);

    
    
    
   [uiDurationSlider setValue:tempoIncrease animated:YES];
    [mDiracAudioPlayer changeDuration: 1/(uiDurationSlider.value)];
    uiDurationLabel.text = [NSString stringWithFormat:@"%3.2f", uiDurationSlider.value];
    
    NSLog(@"uiDurationSlider.maximumValue %f",(uiDurationSlider.maximumValue)*100);
    if(BPMValue == (uiDurationSlider.maximumValue)*100)
    {
        
    }
    else
    {
        BPMValue = BPMValue + 1;
        self.lblShowBPM.text = [NSString stringWithFormat:@"%d",BPMValue];
    }
    
    if(BPMValue >=200)
    {
        if(LoadedAudio ==  1)
        {
            if([mDiracAudioPlayer playing])
            {
                [mDiracAudioPlayer stop];
                
                NSURL *inUrl = [NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:AudioSelectedName2 ofType: AudioSelectedType2]];
                
                NSError *error = nil;
                
                if(mDiracAudioPlayer)
                    mDiracAudioPlayer = nil;
                
                mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
                [mDiracAudioPlayer setDelegate:self];
                mDiracAudioPlayer.numberOfLoops = -1;
                [mDiracAudioPlayer play];
                
                LoadedAudio = 2;
            }
        }
        else{
            float tempoIncrease = (uiDurationSlider.value) + 0.01;
             sliderValue=tempoIncrease;
            [uiDurationSlider setValue:tempoIncrease animated:YES];
            [mDiracAudioPlayer changeDuration: 1/(uiDurationSlider.value)];
            uiDurationLabel.text = [NSString stringWithFormat:@"%3.2f", uiDurationSlider.value];
        }
    }
    else if(BPMValue <200)
    {
        if(LoadedAudio == 1)
        {
            float tempoIncrease = (uiDurationSlider.value) + 0.01;
             sliderValue=tempoIncrease;
            [uiDurationSlider setValue:tempoIncrease animated:YES];
            [mDiracAudioPlayer changeDuration: 1/(uiDurationSlider.value)];
            uiDurationLabel.text = [NSString stringWithFormat:@"%3.2f", uiDurationSlider.value];
        }
        else {
            if([mDiracAudioPlayer playing])
            {
                [mDiracAudioPlayer stop];
                
                NSString *inputSound  = [[NSBundle mainBundle] pathForResource:AudioSelectedName ofType: AudioSelectedType];
                NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
                
                NSError *error = nil;
                
                if(mDiracAudioPlayer)
                    mDiracAudioPlayer = nil;
                
                mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
                [mDiracAudioPlayer setDelegate:self];
                mDiracAudioPlayer.numberOfLoops = -1;
                [mDiracAudioPlayer play];
                
                LoadedAudio = 1;
            }
            
        }
        
        
        
        
    }
}else
{
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:Nil message:@"Please play audio" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
    [alert show];
    alert=nil;
}
    
    
    
    
       [mDiracAudioPlayer changePitch:powf(2.f, (int)pitchIncrease/ 12.f)];
}
-(IBAction)btnTempoIncreaseByTenClicked
{
    
//    playBtn.hidden=YES;
//    self.pauseBtn.hidden=NO;
//    [mDiracAudioPlayer play];

    
    if (PlayerPlaying==YES) {

    
    //TEMPO +10
    if((BPMValue + 10) < 300)
    {
        BPMValue = BPMValue + 10;
        self.lblShowBPM.text = [NSString stringWithFormat:@"%d",BPMValue];
        float tempoIncrease = (uiDurationSlider.value) + 0.1;
         sliderValue=tempoIncrease;
        [uiDurationSlider setValue:tempoIncrease animated:YES];
        [mDiracAudioPlayer changeDuration: 1/(uiDurationSlider.value)];
        uiDurationLabel.text = [NSString stringWithFormat:@"%3.2f", uiDurationSlider.value];
    }
    else if((BPMValue + 10) >=300)
    {
        BPMValue = 300;
        self.lblShowBPM.text = [NSString stringWithFormat:@"%d",BPMValue];
        
           // float tempoIncrease = (uiDurationSlider.value) + 0.1;
        
            [uiDurationSlider setValue:3 animated:YES];
    [mDiracAudioPlayer changeDuration: 1/(uiDurationSlider.value)];
            uiDurationLabel.text = [NSString stringWithFormat:@"%3.2f", uiDurationSlider.value];
    }
    
    if(BPMValue >=200)
    {
        if(LoadedAudio ==  1)
        {
            if([mDiracAudioPlayer playing])
            {
                [mDiracAudioPlayer stop];
                
             
                NSURL *inUrl = [NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:AudioSelectedName2 ofType: AudioSelectedType2]];
                
                NSError *error = nil;
                
                if(mDiracAudioPlayer)
                    mDiracAudioPlayer = nil;
                
                mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
                [mDiracAudioPlayer setDelegate:self];
                mDiracAudioPlayer.numberOfLoops = -1;
                [mDiracAudioPlayer play];
                
                LoadedAudio = 2;
            }
        }
        else{
//            float tempoIncrease = (uiDurationSlider.value) + 0.1;
//            
//            [uiDurationSlider setValue:tempoIncrease animated:YES];
//            [mDiracAudioPlayer changeDuration: 1/(uiDurationSlider.value)];
//            uiDurationLabel.text = [NSString stringWithFormat:@"%3.2f", uiDurationSlider.value];
        }
    }
    else if(BPMValue <200)
    {
        if(LoadedAudio == 1)
        {
//            float tempoIncrease = (uiDurationSlider.value) + 0.1;
//            
//            [uiDurationSlider setValue:tempoIncrease animated:YES];
//            [mDiracAudioPlayer changeDuration: 1/(uiDurationSlider.value)];
//            uiDurationLabel.text = [NSString stringWithFormat:@"%3.2f", uiDurationSlider.value];
        }
        else if(LoadedAudio == 2){
            if([mDiracAudioPlayer playing])
            {
                [mDiracAudioPlayer stop];
                
                NSString *inputSound  = [[NSBundle mainBundle] pathForResource:AudioSelectedName ofType: AudioSelectedType];
                NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
                
                NSError *error = nil;
                
                if(mDiracAudioPlayer)
                    mDiracAudioPlayer = nil;
                
                mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
                [mDiracAudioPlayer setDelegate:self];
                mDiracAudioPlayer.numberOfLoops = -1;
                [mDiracAudioPlayer play];
                
                LoadedAudio = 1;
            }

        }
    }
    }else
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:Nil message:@"Please play audio" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];
        alert=nil;
    }
//
 [mDiracAudioPlayer changePitch:powf(2.f, (int)pitchIncrease/ 12.f)];
}
-(IBAction)btnTempoDecreaseByOneClicked
{
      if (PlayerPlaying==YES) {
    
//    playBtn.hidden=YES;
//    self.pauseBtn.hidden=NO;
//    [mDiracAudioPlayer play];

    
//    float tempoDecrease = (uiDurationSlider.value) - 0.01;
//    
//    [uiDurationSlider setValue:tempoDecrease animated:YES];
//    [mDiracAudioPlayer changeDuration: 1/(uiDurationSlider.value)];
//    uiDurationLabel.text = [NSString stringWithFormat:@"%3.2f", uiDurationSlider.value];
//    if (PlayerPlaying==YES) {

    if(BPMValue == (uiDurationSlider.minimumValue)*100)
    {
        
    }
    else{
        BPMValue = BPMValue - 1;
        self.lblShowBPM.text = [NSString stringWithFormat:@"%d",BPMValue];
        
    }

    if(BPMValue <200)
    {
        if(LoadedAudio == 2)
        {
            if([mDiracAudioPlayer playing])
            {
                [mDiracAudioPlayer stop];
                
                NSString *inputSound  = [[NSBundle mainBundle] pathForResource:AudioSelectedName ofType: AudioSelectedType];
                NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
                
                NSError *error = nil;
                
                if(mDiracAudioPlayer)
                    mDiracAudioPlayer = nil;
                
                mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
                [mDiracAudioPlayer setDelegate:self];
                mDiracAudioPlayer.numberOfLoops = -1;
                [mDiracAudioPlayer play];
                
                LoadedAudio = 1;
            }
        }
        else{
            float tempoDecrease = (uiDurationSlider.value) - 0.01;
               sliderValue=tempoDecrease;
            [uiDurationSlider setValue:tempoDecrease animated:YES];
            [mDiracAudioPlayer changeDuration: 1/(uiDurationSlider.value)];
            uiDurationLabel.text = [NSString stringWithFormat:@"%3.2f", uiDurationSlider.value];
        }
    }
    else if(BPMValue >=200)
    {
        if(LoadedAudio == 1)
        {
            if([mDiracAudioPlayer playing])
            {
                [mDiracAudioPlayer stop];
                
                NSString *inputSound  = [[NSBundle mainBundle] pathForResource:AudioSelectedName2 ofType: AudioSelectedType2];
                NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
                
                NSError *error = nil;
                
                if(mDiracAudioPlayer)
                    mDiracAudioPlayer = nil;
                
                mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
                [mDiracAudioPlayer setDelegate:self];
                mDiracAudioPlayer.numberOfLoops = -1;
                [mDiracAudioPlayer play];
                
                LoadedAudio = 2;
            }
        }
        else{
            float tempoDecrease = (uiDurationSlider.value) - 0.01;
               sliderValue=tempoDecrease;
            [uiDurationSlider setValue:tempoDecrease animated:YES];
            [mDiracAudioPlayer changeDuration: 1/(uiDurationSlider.value)];
            uiDurationLabel.text = [NSString stringWithFormat:@"%3.2f", uiDurationSlider.value];
        }
    }
    }else
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:Nil message:@"Please play audio" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];
        alert=nil;
    }
     [mDiracAudioPlayer changePitch:powf(2.f, (int)pitchIncrease/ 12.f)];
}
-(IBAction)btnTempoDecreaseByTenClicked
{
    
//    playBtn.hidden=YES;
//    self.pauseBtn.hidden=NO;
//    [mDiracAudioPlayer play];

    
     if (PlayerPlaying==YES) {
   

    //TEMPO -10
    if((BPMValue - 10) >= 10)
    {
        BPMValue = BPMValue - 10;
        self.lblShowBPM.text = [NSString stringWithFormat:@"%d",BPMValue];
        
            float tempoDecrease = (uiDurationSlider.value) - 0.1;
           sliderValue=tempoDecrease;
            [uiDurationSlider setValue:tempoDecrease animated:YES];
            [mDiracAudioPlayer changeDuration: 1/(uiDurationSlider.value)];
            uiDurationLabel.text = [NSString stringWithFormat:@"%3.2f", uiDurationSlider.value];
    }
    else
    {
        BPMValue = 0;
        self.lblShowBPM.text = [NSString stringWithFormat:@"%d",BPMValue];
       //     float tempoDecrease = (uiDurationSlider.value) - 0.1;
        
            [uiDurationSlider setValue:0 animated:YES];
            [mDiracAudioPlayer changeDuration: 0];
            uiDurationLabel.text = [NSString stringWithFormat:@"%3.2f", uiDurationSlider.value];
    }
//        if((BPMValue - 10) <=50)
//    {
//        BPMValue = 50;
//        self.lblShowBPM.text = [NSString stringWithFormat:@"%d",BPMValue];
//    }
//
    if(BPMValue <200)
    {
        if(LoadedAudio == 2)
        {
            if([mDiracAudioPlayer playing])
            {
                [mDiracAudioPlayer stop];
                
                NSString *inputSound  = [[NSBundle mainBundle] pathForResource:AudioSelectedName ofType: AudioSelectedType];
                NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
                
                NSError *error = nil;
                
                if(mDiracAudioPlayer)
                    mDiracAudioPlayer = nil;
                
                mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
                [mDiracAudioPlayer setDelegate:self];
                mDiracAudioPlayer.numberOfLoops = -1;
                [mDiracAudioPlayer play];
                
                LoadedAudio = 1;
                
                self.segmentContolForChangingAudio.selectedSegmentIndex = 0;
            }
        }
        else{
//            float tempoDecrease = (uiDurationSlider.value) - 0.1;
//            
//            [uiDurationSlider setValue:tempoDecrease animated:YES];
//            [mDiracAudioPlayer changeDuration: 1/(uiDurationSlider.value)];
//            uiDurationLabel.text = [NSString stringWithFormat:@"%3.2f", uiDurationSlider.value];
        }
    }
    else if(BPMValue >=200)
    {
        if(LoadedAudio == 1)
        {
            if([mDiracAudioPlayer playing])
            {
                [mDiracAudioPlayer stop];
                
                NSString *inputSound  = [[NSBundle mainBundle] pathForResource:AudioSelectedName2 ofType: AudioSelectedType2];
                NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
                
                NSError *error = nil;
                
                if(mDiracAudioPlayer)
                    mDiracAudioPlayer = nil;
                
                mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
                [mDiracAudioPlayer setDelegate:self];
                mDiracAudioPlayer.numberOfLoops = -1;
                [mDiracAudioPlayer play];
                
                LoadedAudio = 2;
            }
        }
        else{
//            float tempoDecrease = (uiDurationSlider.value) - 0.1;
//            
//            [uiDurationSlider setValue:tempoDecrease animated:YES];
//            [mDiracAudioPlayer changeDuration: 1/(uiDurationSlider.value)];
//            uiDurationLabel.text = [NSString stringWithFormat:@"%3.2f", uiDurationSlider.value];
        }
    }
    }else
    {
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:Nil message:@"Please play audio" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];
        alert=nil;
    }
 [mDiracAudioPlayer changePitch:powf(2.f, (int)pitchIncrease/ 12.f)];
}
-(IBAction)btnSegmentControlClicked
{
 //   if (PlayerPlaying==YES) {

    
    playBtn.hidden=YES;
    self.pauseBtn.hidden=NO;
    
    
    if (AudioSelectedName && AudioSelectedName2) {
    if(self.segmentContolForChangingAudio.selectedSegmentIndex == 0)
    {
        LoadedAudio = 1;
        NSLog(@"AUDIO 1");
        [uiDurationSlider setValue:currentValue+1 animated:YES];
        [uiPitchSlider setValue:currentValue animated:YES];
        self.lblShowBPM.text = @"100";
        uiPitchLabel.text = @"0";
        self.btnPitchIncrease.enabled = YES;
        self.btnPitchDecrease.enabled = YES;
        BPMValue = 100;
        
//        if([mDiracAudioPlayer playing])
//        {
           
//            
//            NSString *inputSound  = [[NSBundle mainBundle] pathForResource: AudioSelectedName ofType: AudioSelectedType];
//            NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
//            
//            NSError *error = nil;
//            
//            if(mDiracAudioPlayer)
//                mDiracAudioPlayer = nil;
//            
//            mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
//            [mDiracAudioPlayer setDelegate:self];
//            mDiracAudioPlayer.numberOfLoops = -1;
//            [mDiracAudioPlayer play];
//        }
//        else{
        
        [mDiracAudioPlayer stop];
    
        mDiracAudioPlayer=nil;
            NSString *inputSound  = [[NSBundle mainBundle] pathForResource: AudioSelectedName ofType: AudioSelectedType];
            NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
            
            NSError *error = nil;
            
            if(mDiracAudioPlayer)
                mDiracAudioPlayer = nil;
            
            mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
            [mDiracAudioPlayer setDelegate:self];
        mDiracAudioPlayer.numberOfLoops = -1;
                    [mDiracAudioPlayer play];
//        }

        
        
        
    }
    else if(self.segmentContolForChangingAudio.selectedSegmentIndex == 1)
    {
        LoadedAudio = 2;
        
        NSLog(@"AUDIO 2");
        [uiDurationSlider setValue:currentValue+2 animated:YES];
        [uiPitchSlider setValue:currentValue animated:YES];
        uiPitchLabel.text = @"0";
        self.lblShowBPM.text = @"200";
        self.btnPitchDecrease.enabled = YES;
        self.btnPitchIncrease.enabled = YES;
        BPMValue = 200;
        
//        if([mDiracAudioPlayer playing])
//        {
//            [mDiracAudioPlayer stop];
//            
//            NSString *inputSound  = [[NSBundle mainBundle] pathForResource: AudioSelectedName2 ofType: AudioSelectedType2];
//            NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
//            
//            NSError *error = nil;
//            
//            if(mDiracAudioPlayer)
//                mDiracAudioPlayer = nil;
//            
//            mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
//            [mDiracAudioPlayer setDelegate:self];
//            mDiracAudioPlayer.numberOfLoops = -1;
//            [mDiracAudioPlayer play];
//            
//        }
//        else{
        [mDiracAudioPlayer stop];
     
        mDiracAudioPlayer=nil;
            NSString *inputSound  = [[NSBundle mainBundle] pathForResource: AudioSelectedName2 ofType: AudioSelectedType2];
            NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
            
            NSError *error = nil;
            
            if(mDiracAudioPlayer)
                mDiracAudioPlayer = nil;
            
            mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
        [mDiracAudioPlayer setDelegate:self];
        mDiracAudioPlayer.numberOfLoops = -1;
                   [mDiracAudioPlayer play];
        }
 //   }
}
//    }else
//    {
//        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:Nil message:@"Please play audio" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
//        [alert show];
//        alert=nil;
//    }
}

- (IBAction)addPresetsBtn:(id)sender {
    
    
    
    
    
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:nil message:@"Do you want save preset" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles: @"OK",nil];
    [alert show];
    


}
-(NSString *)databasePath{
    
    NSString *documents=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString *databasePath=[documents stringByAppendingPathComponent:@"italeemPresets.sqlite"];
    NSFileManager *fileManger=[NSFileManager defaultManager];
    if (![fileManger fileExistsAtPath:databasePath]) {
        NSString *bundlePath=[[NSBundle mainBundle]pathForResource:@"italeemPresets" ofType:@"sqlite"];
        [fileManger copyItemAtPath:bundlePath toPath:databasePath error:nil];
        
    }
    return  databasePath;
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    
    
    if (alertView.tag==1) {
        if(buttonIndex==1)
        {
            
            
        
            
            
            NSString *presetName=[alertView textFieldAtIndex:0].text;
            
            if (!presetName.length>0) {
                presetName=@"Untitled preset";
            }
            
            
                    NSString *databasePath = [self databasePath];
                    FMDatabase *database = [FMDatabase databaseWithPath:databasePath];
                    [database open];
            
            
    
            
            NSLog(@"%@",self.lblShowPitchNode.text);
             NSLog(@"%@",uiPitchLabel.text);
             NSLog(@"%@",self.lblShowPitchNode.text);
            
                    BOOL isSuccess = [database executeUpdate:@"INSERT INTO presets_table (main_cat,sub_cat, instrument,tempo,tempo_value,pitch_name,pitch_value,audio_name,audio_type,audio_name2,audio_type2,preset_name) VALUES (?,?,?,?,?,?,?,?,?,?,?,?);",MaintaalsLbl.text,songName.text,subTaals.text, [NSString stringWithFormat:@"%d",[self.lblShowBPM.text integerValue]],[NSString stringWithFormat:@"%f", uiDurationSlider.value]  ,self.lblShowPitchNode.text,uiPitchLabel.text ,AudioSelectedName,AudioSelectedType,AudioSelectedName2,AudioSelectedType2,presetName];
            
            
                   if (isSuccess) {
                        // Fetch all users
                        FMResultSet *results = [database executeQuery:@"select * from presets_table"];
            
                        //   [commonarray removeAllObjects];
            
                       while([results next]) {
                            NSString *name = [results stringForColumn:@"audio_name"];
                            NSString *phone  = [results stringForColumn:@"tempo"];
                            //   NSLog(@"audio_name: %@ - %@",name, phone);
            
                            NSLog(@"%@",[results stringForColumn:@"pitch_value"]);
            
                            //       [commonarray addObject:[results resultDict]];
            
            
            
                        }
                       
                       
                        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:nil message:@"Preset successfully added" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
                        [alert show];
                        alert=nil;
        }
        
                [database close];
            
        }
    }
    else
    {
	if(buttonIndex==1)
	{
        
        UIAlertView* dialog = [[UIAlertView alloc] init];
        [dialog setDelegate:self];
        [dialog setTitle:@"Enter Preset Name"];
        [dialog setMessage:nil];
        [dialog addButtonWithTitle:@"Cancel"];
        [dialog addButtonWithTitle:@"OK"];
        dialog.tag=1;
        dialog.alertViewStyle = UIAlertViewStylePlainTextInput;
//      UITextField * nameField = [[UITextField alloc] initWithFrame:CGRectMake(20.0, 20, 245.0, 25.0)];
//        [nameField setBackgroundColor:[UIColor whiteColor]];
//        [dialog addSubview:nameField];
        
        
        
        
        CGAffineTransform moveUp = CGAffineTransformMakeTranslation(0.0, 100.0);
        [dialog setTransform: moveUp];
        [dialog show];
        
    }

        
    }

}
-(IBAction)btnPitchIncreaseClicked
{
//

    
//    if (PlayerPlaying==YES) {
    
        
//        playBtn.hidden=YES;
//        self.pauseBtn.hidden=NO;
//        [mDiracAudioPlayer play];
        
        if (pitchIncrease<self.arrPitchNodes.count-1) {
            pitchIncrease=pitchIncrease+1;
            self.lblShowPitchNode.text=[self.arrPitchNodes objectAtIndex:pitchIncrease];
            [mDiracAudioPlayer changePitch:powf(2.f, (int)pitchIncrease / 12.f)];
            uiPitchLabel.text=[NSString stringWithFormat:@"%d",pitchIncrease];
        }

//
//    
//    self.btnPitchDecrease.enabled = YES;
//    
//    NSLog(@"ARR COUNT %d",[self.arrPitchNodes count]);
//    NSLog(@"COUNT %d",count);
//    NSLog(@"SLIDER %f",uiPitchSlider.value);
//    
//    if([uiPitchLabel.text intValue] >= self.arrPitchNodes.count-1)
//    {
//        self.btnPitchIncrease.enabled = NO;
//    }
//    else{
//        if ((count<[self.arrPitchNodes count]-1)) { // && (count!=([self.arrPitchNodes count]-1))
//            count++;
//        }
//        else{
//            count = 0;
//        }
//        if(count <= [self.arrPitchNodes count])
//        {
//            float pitchIncrease = uiPitchSlider.value + 1;
//            [uiPitchSlider setValue:pitchIncrease animated:YES];
//            [mDiracAudioPlayer changePitch:powf(2.f, (int)uiPitchSlider.value / 12.f)];
//            uiPitchLabel.text = [NSString stringWithFormat:@"%d", (int)uiPitchSlider.value];
//            
//            self.lblShowPitchNode.text = [NSString stringWithFormat:@"%@",[self.arrPitchNodes objectAtIndex:count]];
//            
//            NSLog(@"%@",[NSString stringWithFormat:@"%@",[self.arrPitchNodes objectAtIndex:count]]);
//            
//            NSLog(@"After COUNT %d",count);
//        }
//    }
//    }else
//    {
//        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:Nil message:@"Please play audio" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
//        [alert show];
//        alert=nil;
//    }
//    
   
}
-(IBAction)btnPitchDecreaseClicked
{
//    if (PlayerPlaying==YES) {
////
//    playBtn.hidden=YES;
//    self.pauseBtn.hidden=NO;
//    [mDiracAudioPlayer play];
//        
    
        if (pitchIncrease>0) {
            pitchIncrease=pitchIncrease-1;
            self.lblShowPitchNode.text=[self.arrPitchNodes objectAtIndex:pitchIncrease];
            [mDiracAudioPlayer changePitch:powf(2.f, (int)pitchIncrease / 12.f)];
            uiPitchLabel.text=[NSString stringWithFormat:@"%d",pitchIncrease];
            //   [self updatePitch];
        }
        
        
        
//
//    if ([uiPitchLabel.text intValue]>0) {
//        
//
//        
//        self.btnPitchIncrease.enabled = YES;
//        self.btnPitchDecrease.enabled = YES;
//        
////        if([uiPitchLabel.text intValue] <= -5)
////        {
////            self.btnPitchDecrease.enabled = NO;
////            
////        }
////        else{
////            if(count==0){
////                boolDecrement = FALSE;
////                count=[self.arrPitchNodes count]-1;
////                
////                
////            }
//            if(count > 0 && boolDecrement){
//                count--;
//                
//            }
//            if((count < [self.arrPitchNodes count])&& count>=0)
//            {
//                boolDecrement = TRUE;
//                float pitchDecrease = uiPitchSlider.value - 1;
//                [uiPitchSlider setValue:pitchDecrease animated:YES];
//                [mDiracAudioPlayer changePitch:powf(2.f, (int)uiPitchSlider.value / 12.f)];
//                uiPitchLabel.text = [NSString stringWithFormat:@"%d", (int)uiPitchSlider.value];
//                
//                self.lblShowPitchNode.text = [NSString stringWithFormat:@"%@",[self.arrPitchNodes objectAtIndex:count]];
//            }
////         }
//    }
//    }else
//    {
//        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:Nil message:@"Please play audio" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
//        [alert show];
//        alert=nil;
//    }
//    
 
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
- (void)viewDidUnload {
    [self setPauseBtn:nil];
   
    stopBtn = nil;
 
    playBtn = nil;

    songName = nil;

}

- (IBAction)openAudioList:(id)sender {
//    actionSheet.hidden=YES;
//    actionSheet=nil;
    
    if (mainpickerClicked==YES) {
        NSLog(@"CompleteArray---%@",CompleteArray);
        
        [CompleteArray removeAllObjects];
        CompleteArray=Nil;
        CompleteArray =[[NSMutableArray alloc]initWithArray:[[MaintaalsDic objectForKey:MaintaalsLbl.text] allKeys]];
        
        PickerType=@"subtaal";
        actionSheet = [[UIActionSheet alloc]initWithTitle:@"Please select audio" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:nil];
        [actionSheet showInView:self.view];
        actionSheet.backgroundColor=[UIColor whiteColor];
        [actionSheet setBounds:CGRectMake(0, 0, 320, 350)];
        
       pickerView = [[UIPickerView alloc]initWithFrame:CGRectMake(0, 40, 320, 140)];
        pickerView.delegate = self;
        // pickerView.dataSource = self;
        pickerView.showsSelectionIndicator = YES;
        
        UITapGestureRecognizer* gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pickerViewTapGestureRecognized:)];
        gestureRecognizer.cancelsTouchesInView = NO;
        [pickerView addGestureRecognizer:gestureRecognizer];

        
        UIToolbar *pickerToolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
        pickerToolbar.barStyle = UIBarStyleBlack;
        [pickerToolbar sizeToFit];
        
        UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStyleBordered target:self action:@selector(cancelButtonClicked)];
        cancelButton.tintColor=[UIColor whiteColor];
     
        UIBarButtonItem *flex = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil] ;
        
        flex.title=@"Please select audio";
        
//        UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(pickerDoneClicked)] ;
//        doneButton.tintColor=[UIColor whiteColor];
        
        [pickerToolbar setItems:[NSArray arrayWithObjects:cancelButton,flex,nil]];
        [actionSheet addSubview:pickerToolbar];
        [actionSheet addSubview:pickerView];
        pickerSelection=0;
    }
}
-(void)cancelButtonClicked
{
    toolView.hidden=YES;
    toolView=nil;
    [actionSheet dismissWithClickedButtonIndex:0 animated:YES];
  
//    [actionSheet removeFromSuperview];
//    actionSheet=nil;
}
-(void)pickerDoneClicked
{
    PlayerPlaying=YES;
   
    toolView.hidden=YES;
    toolView=nil;
 
    [actionSheet dismissWithClickedButtonIndex:0 animated:YES];
    [mDiracAudioPlayer stop];
    mDiracAudioPlayer=Nil;
    
    if ([PickerType isEqualToString:@"subtaal"])
    {
        subpickerClicked=YES;
        if (pickerSelection==0) {
              songName.text=[CompleteArray objectAtIndex:0];
        }else
        {
            songName.text=[CompleteArray objectAtIndex:indexPicker];
        }
    }else if ([PickerType isEqualToString:@"maintaals"])
    {
        mainpickerClicked=YES;
        subpickerClicked=NO;
        if (pickerSelection==0)
        {
        MaintaalsLbl.text=[[MaintaalsDic allKeys] objectAtIndex:0];
        }else
   {
        MaintaalsLbl.text=[[MaintaalsDic allKeys] objectAtIndex:indexPicker];
    }
    }
    else
    {
        if (pickerSelection==0) {
            subTaals.text=[[CompleteArray objectAtIndex:0] objectForKey:@"Name"];
            AudioSelectedName=[[CompleteArray objectAtIndex:0] objectForKey:@"Audio1"];
            AudioSelectedType=[[CompleteArray objectAtIndex:0] objectForKey:@"Audio1_Type"];
            NSLog(@"%@",AudioSelectedName);
            
            
            AudioSelectedName2=[[CompleteArray objectAtIndex:0] objectForKey:@"Audio2"];
            AudioSelectedType2=[[CompleteArray objectAtIndex:0] objectForKey:@"Audio2_Type"];
            
            NSLog(@"%@",AudioSelectedName);
            
            NSString *inputSound ;
            
            if ([self.lblShowBPM.text integerValue]<200) {
                inputSound  = [[NSBundle mainBundle] pathForResource:  AudioSelectedName ofType:AudioSelectedType];
            }else
            {
                inputSound  = [[NSBundle mainBundle] pathForResource:  AudioSelectedName2 ofType:AudioSelectedType2];
            }

            NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
            
            NSError *error = nil;
            mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];
            [mDiracAudioPlayer setDelegate:self];
            [mDiracAudioPlayer setNumberOfLoops:-1];
            
            mUseVarispeed = NO;
            [mDiracAudioPlayer play];

        }else
        {
            
            ArrayIndexNunber=indexPicker;
            subTaals.text=[[CompleteArray objectAtIndex:indexPicker] objectForKey:@"Name"] ;
            
            AudioSelectedName=[[CompleteArray objectAtIndex:indexPicker] objectForKey:@"Audio1"];
            AudioSelectedType=[[CompleteArray objectAtIndex:indexPicker] objectForKey:@"Audio1_Type"];
            NSLog(@"%@",AudioSelectedName);
            
            
            AudioSelectedName2=[[CompleteArray objectAtIndex:indexPicker] objectForKey:@"Audio2"];
            AudioSelectedType2=[[CompleteArray objectAtIndex:indexPicker] objectForKey:@"Audio2_Type"];
            
            NSLog(@"%@",AudioSelectedName);
            
            NSString *inputSound ;
            
            if ([self.lblShowBPM.text integerValue]<200) {
                  inputSound  = [[NSBundle mainBundle] pathForResource:  AudioSelectedName ofType:AudioSelectedType];
            }else
            {
              inputSound  = [[NSBundle mainBundle] pathForResource:  AudioSelectedName2 ofType:AudioSelectedType2];
            }
            NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
            NSError *error = nil;
            mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];
            [mDiracAudioPlayer setDelegate:self];
            [mDiracAudioPlayer setNumberOfLoops:-1];
            
            mUseVarispeed = NO;
            [mDiracAudioPlayer play];
            
        }
        [mDiracAudioPlayer changeDuration: 1/(sliderValue)];
        
    }
    LoadedAudio=1;
    
    if ([PickerType isEqualToString:@"maintaals"])
    {
        [mDiracAudioPlayer stop];
        mDiracAudioPlayer=Nil;
        subTaals.text=@"Select Instruments";
          songName.text=@"Select Taals";
        
        self.pauseBtn.hidden=YES;
        playBtn.hidden=NO;
        
         [durationView removeFromSuperview];
        [timer invalidate];
        [stopWatchTimer invalidate];
        stopWatchTimer=Nil;
        startDate=nil;
    
    }
    else if ([PickerType isEqualToString:@"subtaal"] )
    {
          [mDiracAudioPlayer stop];
          mDiracAudioPlayer=Nil;
          subTaals.text=@"Select Instruments";
        
        self.pauseBtn.hidden=YES;
        playBtn.hidden=NO;
        
        
        [durationView removeFromSuperview];
        [timer invalidate];
        [stopWatchTimer invalidate];
        stopWatchTimer=Nil;
        startDate=nil;
      
      }else
      {
          
          self.pauseBtn.hidden=NO;
          playBtn.hidden=YES;
          [mDiracAudioPlayer play];
        
          
          
          
//          timer = [NSTimer scheduledTimerWithTimeInterval:30
//                                                   target:self
//                                                 selector:@selector(handleTimer)
//                                                 userInfo:nil
//                                                  repeats:YES];
          
          
       
          [stopWatchTimer invalidate];
          stopWatchTimer=Nil;
          startDate=nil;
//          double delayInSeconds = 0;
//          dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
//          dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
//              
//              startDate = [NSDate date]  ;
//              
//              stopWatchTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(updateTimer) userInfo:nil repeats:YES];
//              
//              
//          });

      }
    
    
    
//    [mDiracAudioPlayer changePitch:powf(2.f, pitchValue / 12.f)];
//    
//    uiPitchLabel.text = [NSString stringWithFormat:@"%d", pitchValue];
//    
//    self.lblShowPitchNode.text = [NSString stringWithFormat:@"%@",[[notification object] objectForKey:@"pitch_name"]] ;
}

#pragma mark- picker delegate method
- (void)pickerView:(UIPickerView *)pickerView didSelectRow: (NSInteger)row inComponent:(NSInteger)component {
//    pickerSelection = 1;
//    
//     if ([PickerType isEqualToString:@"maintaals"] )
//     {
//     }else if ([PickerType isEqualToString:@"subtaal"])
//     {
//         
//     }else
//     {
//     
//    if (row == 0)
//    {
//        AudioSelectedName=[[CompleteArray objectAtIndex:0] objectForKey:@"Audio1"];
//        AudioSelectedType=[[CompleteArray objectAtIndex:0] objectForKey:@"Audio1_Type"];
//        
//        AudioSelectedName2=[[CompleteArray objectAtIndex:0] objectForKey:@"Audio2"];
//        AudioSelectedType2=[[CompleteArray objectAtIndex:0] objectForKey:@"Audio2_Type"];
//    }
//    else
//    {
//        NSLog(@"%d",row);
//        AudioSelectedName=[[CompleteArray objectAtIndex:row] objectForKey:@"Audio1"];
//        AudioSelectedType=[[CompleteArray objectAtIndex:row] objectForKey:@"Audio1_Type"];
//        
//        AudioSelectedName2=[[CompleteArray objectAtIndex:row] objectForKey:@"Audio2"];
//        AudioSelectedType2=[[CompleteArray objectAtIndex:row] objectForKey:@"Audio2_Type"];
//    }
//     }
//    indexPicker=row;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {

    if ([PickerType isEqualToString:@"subtaal"])
    {
          return [CompleteArray  count];
    }
    else  if ([PickerType isEqualToString:@"maintaals"])
    {
    return [[MaintaalsDic allKeys] count];
    }
    else
    {
    return [CompleteArray count];
    }
}
// tell the picker how many components it will have
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}
// tell the picker the title for a given component
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component {
    
    if ([PickerType isEqualToString:@"subtaal"]) {
          return [NSString stringWithFormat:@"%@",[CompleteArray  objectAtIndex:row]];
    }
    else  if ([PickerType isEqualToString:@"maintaals"])
    {
         return [NSString stringWithFormat:@"%@",[[MaintaalsDic allKeys] objectAtIndex:row]];
    }
    else
    {
          return [NSString stringWithFormat:@"%@",[[CompleteArray objectAtIndex:row] objectForKey:@"Name"]];
    }
}
// tell the picker the width of each row for a given component
- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
    int sectionWidth = 300;
    
    return sectionWidth;
}
#pragma mark- picker gesture method
- (void)pickerViewTapGestureRecognized:(UITapGestureRecognizer*)gestureRecognizer
{
    
    NSInteger row = [pickerView selectedRowInComponent:0];
    
    pickerSelection = 1;
    
    if ([PickerType isEqualToString:@"maintaals"] )
    {
    }else if ([PickerType isEqualToString:@"subtaal"])
    {
        
    }else
    {
        
        if (row == 0)
        {
            AudioSelectedName=[[CompleteArray objectAtIndex:0] objectForKey:@"Audio1"];
            AudioSelectedType=[[CompleteArray objectAtIndex:0] objectForKey:@"Audio1_Type"];
            
            AudioSelectedName2=[[CompleteArray objectAtIndex:0] objectForKey:@"Audio2"];
            AudioSelectedType2=[[CompleteArray objectAtIndex:0] objectForKey:@"Audio2_Type"];
        }
        else
        {
            NSLog(@"%d",row);
            AudioSelectedName=[[CompleteArray objectAtIndex:row] objectForKey:@"Audio1"];
            AudioSelectedType=[[CompleteArray objectAtIndex:row] objectForKey:@"Audio1_Type"];
            
            AudioSelectedName2=[[CompleteArray objectAtIndex:row] objectForKey:@"Audio2"];
            AudioSelectedType2=[[CompleteArray objectAtIndex:row] objectForKey:@"Audio2_Type"];
        }
    }
    indexPicker=row;
    [self pickerDoneClicked];
}

- (IBAction)audio2Action:(id)sender {
//    if (PlayerPlaying==YES) {
    playBtn.hidden=YES;
    self.pauseBtn.hidden=NO;
    PlayerPlaying=YES;
    
        if (AudioSelectedName && AudioSelectedName2) {
           
                LoadedAudio = 2;
                
                NSLog(@"AUDIO 2");
                [uiDurationSlider setValue:currentValue+2 animated:YES];
                [uiPitchSlider setValue:currentValue animated:YES];
                uiPitchLabel.text = [NSString stringWithFormat:@"%d",pitchIncrease];
                self.lblShowBPM.text = @"200";
                self.btnPitchDecrease.enabled = YES;
                self.btnPitchIncrease.enabled = YES;
                BPMValue = 200;
                
                //        if([mDiracAudioPlayer playing])
                //        {
                //            [mDiracAudioPlayer stop];
                //
                //            NSString *inputSound  = [[NSBundle mainBundle] pathForResource: AudioSelectedName2 ofType: AudioSelectedType2];
                //            NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
                //
                //            NSError *error = nil;
                //
                //            if(mDiracAudioPlayer)
                //                mDiracAudioPlayer = nil;
                //
                //            mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
                //            [mDiracAudioPlayer setDelegate:self];
                //            mDiracAudioPlayer.numberOfLoops = -1;
                //            [mDiracAudioPlayer play];
                //
                //        }
                //        else{
                [mDiracAudioPlayer stop];
           
                mDiracAudioPlayer=nil;
                NSString *inputSound  = [[NSBundle mainBundle] pathForResource: AudioSelectedName2 ofType: AudioSelectedType2];
                NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
                
                NSError *error = nil;
                
                if(mDiracAudioPlayer)
                    mDiracAudioPlayer = nil;
                
                mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
                [mDiracAudioPlayer setDelegate:self];
                mDiracAudioPlayer.numberOfLoops = -1;
                [mDiracAudioPlayer play];
            }
    
    
      [mDiracAudioPlayer changePitch:powf(2.f, pitchIncrease / 12.f)];
 //       }
}
- (IBAction)audio1Action:(id)sender {
  //  if (PlayerPlaying==YES) {
    playBtn.hidden=YES;
    self.pauseBtn.hidden=NO;
        PlayerPlaying=YES;
        if (AudioSelectedName && AudioSelectedName2)
        {
                LoadedAudio = 1;
                NSLog(@"AUDIO 1");
                [uiDurationSlider setValue:currentValue+1 animated:YES];
                [uiPitchSlider setValue:currentValue animated:YES];
                self.lblShowBPM.text = @"100";
                uiPitchLabel.text = [NSString stringWithFormat:@"%d",pitchIncrease];
                self.btnPitchIncrease.enabled = YES;
                self.btnPitchDecrease.enabled = YES;
                BPMValue = 100;
                
                //        if([mDiracAudioPlayer playing])
                //        {
                
                //
                //            NSString *inputSound  = [[NSBundle mainBundle] pathForResource: AudioSelectedName ofType: AudioSelectedType];
                //            NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
                //
                //            NSError *error = nil;
                //
                //            if(mDiracAudioPlayer)
                //                mDiracAudioPlayer = nil;
                //
                //            mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
                //            [mDiracAudioPlayer setDelegate:self];
                //            mDiracAudioPlayer.numberOfLoops = -1;
                //            [mDiracAudioPlayer play];
                //        }
                //        else{
                
                [mDiracAudioPlayer stop];
          
                mDiracAudioPlayer=nil;
                NSString *inputSound  = [[NSBundle mainBundle] pathForResource: AudioSelectedName ofType: AudioSelectedType];
                NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
                
                NSError *error = nil;
                
                if(mDiracAudioPlayer)
                    mDiracAudioPlayer = nil;
                
                mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
                [mDiracAudioPlayer setDelegate:self];
                mDiracAudioPlayer.numberOfLoops = -1;
                [mDiracAudioPlayer play];
                //        }
                
                
                
                
            }
          [mDiracAudioPlayer changePitch:powf(2.f, pitchIncrease / 12.f)];
  //  }
}
- (IBAction)instrumentOpenPicker:(id)sender {
    
    
    if (mainpickerClicked==YES && subpickerClicked==YES) {
        PickerType=@"instrument";
        [CompleteArray removeAllObjects];
        CompleteArray=nil;
        
        
        CompleteArray =[[NSMutableArray alloc]initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[[MaintaalsDic objectForKey:MaintaalsLbl.text] objectForKey:songName.text] ofType:@"plist"]];
        NSLog(@"%@",CompleteArray);
        
        
        actionSheet = [[UIActionSheet alloc]initWithTitle:@"Please select audio" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:nil] ;
        [actionSheet showInView:self.view];
        actionSheet.backgroundColor=[UIColor whiteColor];
        [actionSheet setBounds:CGRectMake(0, 0, 320, 350)];
        
        pickerView = [[UIPickerView alloc]initWithFrame:CGRectMake(0, 40, 320, 140)];
        pickerView.delegate = self;
        // pickerView.dataSource = self;
        pickerView.showsSelectionIndicator = YES;
        
        
        UITapGestureRecognizer* gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(pickerViewTapGestureRecognized:)];
        gestureRecognizer.cancelsTouchesInView = NO;
        [pickerView addGestureRecognizer:gestureRecognizer];

        
        UIToolbar *pickerToolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
        pickerToolbar.barStyle = UIBarStyleBlack;
        [pickerToolbar sizeToFit];
        
        
        UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStyleBordered target:self action:@selector(cancelButtonClicked)] ;
        cancelButton.tintColor=[UIColor whiteColor];
    
        
        
        UIBarButtonItem *flex = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
        
        flex.title=@"Please select audio";
        
//        UIBarButtonItem *doneButton = [[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(pickerDoneClicked)] ;
//        doneButton.tintColor=[UIColor whiteColor];
        
        
        [pickerToolbar setItems:[NSArray arrayWithObjects:cancelButton,flex,nil]];
        [actionSheet addSubview:pickerToolbar];
        [actionSheet addSubview:pickerView];
        
        pickerSelection=0;

    }
}
#pragma mark- backgroundAudio Method
- (void) Playpresets:(NSNotification *) notification
{
    
    NSLog(@"%@",[[notification object] objectForKey:@"tempo_value"]);
    uiDurationSlider.value=[[NSString stringWithFormat:@"%@",[[notification object] objectForKey:@"tempo_value"]] floatValue];
    [mDiracAudioPlayer changeDuration: 1/[[NSString stringWithFormat:@"%@",[[notification object] objectForKey:@"tempo_value"]] floatValue]];
    
    
    
  //  float pitchIncrease = [[NSString stringWithFormat:@"%@",[[notification object] objectForKey:@"pitch_value"]] floatValue] + 1;
    
    
    int pitchValue=[[NSString stringWithFormat:@"%@",[[notification object] objectForKey:@"pitch_value"]] integerValue];
    
    
 //   [uiPitchSlider setValue:pitchIncrease animated:YES];
    
    [mDiracAudioPlayer changePitch:powf(2.f, pitchValue / 12.f)];
    
    uiPitchLabel.text = [NSString stringWithFormat:@"%d", pitchValue];
       [mDiracAudioPlayer changePitch:powf(2.f, (int)[[NSString stringWithFormat:@"%d", pitchValue] integerValue]/ 12.f)];
    self.lblShowPitchNode.text = [NSString stringWithFormat:@"%@",[[notification object] objectForKey:@"pitch_name"]] ;
    NSLog(@"%@",[NSString stringWithFormat:@"%@",[[notification object] objectForKey:@"pitch_name"]]);
    
    
    MaintaalsLbl.text=[NSString stringWithFormat:@"%@",[[notification object] objectForKey:@"main_cat"]];
      songName.text=[NSString stringWithFormat:@"%@",[[notification object] objectForKey:@"sub_cat"]];
      subTaals.text=[NSString stringWithFormat:@"%@",[[notification object] objectForKey:@"instrument"]];
    

self.lblShowBPM.text= [NSString stringWithFormat:@"%@",[[notification object] objectForKey:@"tempo"]];
    
    
    pitchIncrease=[[NSString stringWithFormat:@"%@",[[notification object] objectForKey:@"pitch_value"]] integerValue];
    
    NSLog(@"%d",[[NSString stringWithFormat:@"%@",[[notification object] objectForKey:@"pitch_value"]] integerValue]);
    
}

- (void) StopAudioNotification:(NSNotification *) notification
{
    [stopWatchTimer invalidate];
    self.pauseBtn.hidden=YES;
    playBtn.hidden=NO;
    [mDiracAudioPlayer pause];

}
//- (void) BackgroundAudioNotification:(NSNotification *) notification
//{
//    if ( [[[NSUserDefaults standardUserDefaults] objectForKey:@"BackgroundAudio"] isEqualToString:@"on"]) {
//        [bgPlayer play];
//    }else
//    {
//        [bgPlayer stop];
//    }
////[[NSNotificationCenter defaultCenter] removeObserver:self name:@"BackgroundAudio" object:nil];
//}
- (void) DisplayAudioNotification:(NSNotification *) notification
{
    if ( [[[NSUserDefaults standardUserDefaults] objectForKey:@"DisplayAudio"] isEqualToString:@"on"]) {
        
        if (timer == nil)
        {
//            timer = [NSTimer scheduledTimerWithTimeInterval:30
//                                                     target:self
//                                                   selector:@selector(handleTimer)
//                                                   userInfo:nil
//                                                    repeats:YES];
            
            double delayInSeconds = 0;
            dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                
                startDate = [NSDate date] ;
                
                stopWatchTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(updateTimer) userInfo:nil repeats:YES];
                
            });
        }
    }else
    {
        if (timer != nil)
        {
            [timer invalidate];
            timer = nil;
            
            
            [stopWatchTimer invalidate];
            stopWatchTimer = nil;
            startDate = nil;
        }
    }

}
@end
