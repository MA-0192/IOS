//
//  GlobalValues_iLP.h
//  iCityPediaUniversal
//
//  Created by Vikas Singh on 04/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class DBConn;
@interface GlobalValues : NSObject

@property (strong, nonatomic) NSMutableArray *marrAudioSettings;

+ (id)sharedManager;

@end
