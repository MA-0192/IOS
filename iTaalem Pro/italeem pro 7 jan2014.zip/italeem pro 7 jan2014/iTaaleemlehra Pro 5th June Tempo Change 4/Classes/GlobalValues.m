//
//  GlobalValues_iLP.m
//  iCityPediaUniversal
//
//  Created by Vikas Singh on 04/11/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "GlobalValues.h"

static GlobalValues *sharedGlobalValues = nil;

@implementation GlobalValues

@synthesize marrAudioSettings = _marrAudioSettings;
#pragma mark Singleton Methods

+ (id)sharedManager {
    @synchronized(self) {
        if(sharedGlobalValues == nil)
            sharedGlobalValues = [[super allocWithZone:NULL] init];
    }
    //_dbConn=[[DBConn alloc] init];
    return sharedGlobalValues;
}

+ (id)allocWithZone:(NSZone *)zone {
    //return [[self sharedManager] retain];
	return [self sharedManager];
}

- (id)copyWithZone:(NSZone *)zone {
    return self;
}

- (id)init {
    if (self = [super init])
    {
        self.marrAudioSettings = [[NSMutableArray alloc]init];
    }
        return self;
}



@end


