//
//  PresetPlayerViewController.m
//  DiracAudioPlayerExample
//
//  Created by Vivek Yadav on 11/20/13.
//
//

#import "PresetPlayerViewController.h"

@interface PresetPlayerViewController ()

@end

@implementation PresetPlayerViewController
@synthesize dic,indexNumber,MainIndexNumber;




- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewDidAppear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter]
     postNotificationName:@"StopAudio"
     object:self];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
   
    BOOL isAtLeast7 = [[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0;
    
    if ( isAtLeast7 ) {
        self.edgesForExtendedLayout=UIRectEdgeNone;
        
        self.navigationController.navigationBar.translucent=NO;
    }
    
    
    // Do any additional setup after loading the view from its nib.
   Pitcharr = [[NSArray alloc]initWithObjects:@"C",@"C#",@"D",@"D#",@"E",@"F",@"F#",@"G", @"G#", @"A",@"A#",@"B",nil];
  //  NSLog(@"%@",dic);
    
    
    NSLog(@"%@",[[dic objectAtIndex:indexValue] objectForKey:@"tempo_value"]);
    
     //   NSLog(@"%@",[dic objectAtIndex:[indexNumber integerValue]]  );
    tempoIncrese=0;
    pitchIncrease=[[[dic objectAtIndex:[indexNumber integerValue]] objectForKey:@"pitch_value"] integerValue];
     NSLog(@"%d",pitchIncrease);
    indexValue=[indexNumber integerValue];
    
    MainTaalLbl.text=[[dic objectAtIndex:indexValue] objectForKey:@"main_cat"];
    SubTaalLbl.text=[[dic objectAtIndex:indexValue] objectForKey:@"sub_cat"];
    InstrumentLbl.text=[[dic objectAtIndex:indexValue] objectForKey:@"instrument"];
    TempoLbl.text=[NSString stringWithFormat:@"%@" ,[[dic objectAtIndex:indexValue] objectForKey:@"tempo"] ];
    PitchLbl.text=[[dic objectAtIndex:indexValue] objectForKey:@"pitch_name"];
    
  //  indexValue=[indexNumber integerValue];
    
    [self changedata];
}
- (void)volumeChanged:(NSNotification *)notification
{
    
}
-(void)changedata
{
    if([[[dic objectAtIndex:indexValue] objectForKey:@"tempo"] integerValue]>200)
    {
        NSLog(@"%@",[[dic objectAtIndex:indexValue] objectForKey:@"audio2"]);
         NSLog(@"%@",[[dic objectAtIndex:indexValue] objectForKey:@"audio_type2"]);
        
      NSString *inputSound  = [[NSBundle mainBundle] pathForResource:[[dic objectAtIndex:indexValue] objectForKey:@"audio_name2"] ofType:[[dic objectAtIndex:indexValue] objectForKey:@"audio_type2"]];
        NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
        
        NSError *error = nil;
        [mDiracAudioPlayer stop];
        mDiracAudioPlayer=Nil;
        
        
        mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
        [mDiracAudioPlayer setDelegate:self];
        mDiracAudioPlayer.numberOfLoops = -1;
        
        tempoFinal=[[[dic objectAtIndex:indexValue] objectForKey:@"tempo_value"] floatValue];
        
        	[mDiracAudioPlayer changeDuration: 1/tempoFinal];
        [mDiracAudioPlayer changePitch:powf(2.f, (int)[[[dic objectAtIndex:indexValue] objectForKey:@"pitch_value"] integerValue] / 12.f)];
        [mDiracAudioPlayer play];
        
    }else
    {
        
        NSLog(@"%@",[[dic objectAtIndex:indexValue] objectForKey:@"audio_name"]);
        NSLog(@"%@",[[dic objectAtIndex:indexValue] objectForKey:@"audio_type"]);
        
        NSString *inputSound  = [[NSBundle mainBundle] pathForResource:[[dic objectAtIndex:indexValue] objectForKey:@"audio_name"] ofType:[[dic objectAtIndex:indexValue] objectForKey:@"audio_type"]];
        NSURL *inUrl = [NSURL fileURLWithPath:inputSound];
        
        NSError *error = nil;
        
        [mDiracAudioPlayer stop];
        mDiracAudioPlayer=Nil;
        
        mDiracAudioPlayer = [[DiracAudioPlayer alloc] initWithContentsOfURL:inUrl channels:1 error:&error];		// LE only supports 1 channel!
        [mDiracAudioPlayer setDelegate:self];
        mDiracAudioPlayer.numberOfLoops = -1;
        
        
        tempoFinal=[[[dic objectAtIndex:indexValue] objectForKey:@"tempo_value"] floatValue];
        
        	[mDiracAudioPlayer changeDuration: 1/tempoFinal];
           [mDiracAudioPlayer changePitch:powf(2.f, (int)[[[dic objectAtIndex:indexValue] objectForKey:@"pitch_value"] integerValue] / 12.f)];
        [mDiracAudioPlayer play];
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewDidDisappear:(BOOL)animated
{
    [mDiracAudioPlayer stop];
      mDiracAudioPlayer = nil;
}

- (IBAction)playBtnAction:(id)sender {
    [mDiracAudioPlayer play];
}
- (IBAction)pauseBtnAction:(id)sender {
    
    [mDiracAudioPlayer pause];
}
-(IBAction)previousBtnAction:(id)sender {
    
    if (indexValue>0) {
         indexValue--;
              MainTaalLbl.text=[[dic objectAtIndex:indexValue] objectForKey:@"main_cat"];
        SubTaalLbl.text=[[dic objectAtIndex:indexValue] objectForKey:@"sub_cat"];
        InstrumentLbl.text=[[dic objectAtIndex:indexValue] objectForKey:@"instrument"];
        TempoLbl.text=[NSString stringWithFormat:@"%@" ,[[dic objectAtIndex:indexValue] objectForKey:@"tempo"] ];
        PitchLbl.text=[[dic objectAtIndex:indexValue] objectForKey:@"pitch_name"];
        tempoFinal=[[[dic objectAtIndex:indexValue] objectForKey:@"tempo_value"] floatValue];
         [self changedata];
        
    }
    
     if(indexValue==0)
    {
      //  nextBtn.hidden=NO;
        previousBtn.hidden=YES;
    }
    
      nextBtn.hidden=NO;
    
      NSLog(@"%d",indexValue);
}
-(IBAction)nextBtnAction:(id)sender {
    
    [[NSNotificationCenter defaultCenter]
     postNotificationName:@"AVSystemController_SystemVolumeDidChangeNotification"
     object:self];
    
    
    NSLog(@"%d",indexValue);
     NSLog(@"%d",dic.count);
    
    
    if (indexValue<dic.count-1) {
        indexValue++;
        MainTaalLbl.text=[[dic objectAtIndex:indexValue] objectForKey:@"main_cat"];
        SubTaalLbl.text=[[dic objectAtIndex:indexValue] objectForKey:@"sub_cat"];
        InstrumentLbl.text=[[dic objectAtIndex:indexValue] objectForKey:@"instrument"];
        TempoLbl.text=[NSString stringWithFormat:@"%@" ,[[dic objectAtIndex:indexValue] objectForKey:@"tempo"] ];
        PitchLbl.text=[[dic objectAtIndex:indexValue] objectForKey:@"pitch_name"];
        NSLog(@"%d",indexValue);
        tempoFinal=[[[dic objectAtIndex:indexValue] objectForKey:@"tempo_value"] floatValue];
        
        [self changedata];
        
        
    }
     if(indexValue==dic.count-1)
    {
        nextBtn.hidden=YES;
       
    }
    
     previousBtn.hidden=NO;
     NSLog(@"%d",indexValue);
}

- (IBAction)stopBtnAction:(id)sender {
    
    
    [mDiracAudioPlayer stop];
}
- (IBAction)tempoDownTen:(id)sender {
    
    
      if ([TempoLbl.text integerValue]>10) {
          
          tempoIncrese=tempoIncrese-0.10;
 //   NSLog(@" tempoIncrese-----> %f",tempoIncrese );

          
          
   // NSLog(@"[dic objectAtIndex:indexValue]---->%@",[dic objectAtIndex:indexValue]);
       
          NSLog(@"[[[dic objectAtIndex:indexValue] objectForKey:@tempo_value] floatValue]---->%f",[[[dic objectAtIndex:indexValue] objectForKey:@"tempo_value"] floatValue]);

          
          
  //  NSLog(@"final tempo %f",1/([[[dic objectAtIndex:indexValue] objectForKey:@"tempo_value"] floatValue]+tempoIncrese));
          
          
          
          
          
          
          TempoLbl.text=[NSString stringWithFormat:@"%d",[TempoLbl.text integerValue]-10];
          [mDiracAudioPlayer changeDuration: 1/([[[dic objectAtIndex:indexValue] objectForKey:@"tempo_value"] floatValue]+tempoIncrese)];
          NSLog(@"%f",tempoIncrese );
          
          
          tempoFinal=([[[dic objectAtIndex:indexValue] objectForKey:@"tempo_value"] floatValue]+tempoIncrese);
              NSLog(@"tempoFinal---->%f",tempoFinal );
          
          
          [self updateTempo];

          
      }
    
  }

- (IBAction)tempoUpTen:(id)sender {
    
    if ([TempoLbl.text integerValue]<=290) {
        tempoIncrese=tempoIncrese+0.10;
        
       
        
        
        
        TempoLbl.text=[NSString stringWithFormat:@"%d",[TempoLbl.text integerValue]+10];
        
            tempoFinal= ([[[dic objectAtIndex:indexValue] objectForKey:@"tempo_value"] floatValue]+tempoIncrese);
        
        [mDiracAudioPlayer changeDuration: 1/tempoFinal];
        NSLog(@"tempoFinal---->%f",tempoFinal );
        
           NSLog(@"%f", 1/([[[dic objectAtIndex:indexValue] objectForKey:@"tempo_value"] floatValue]+tempoIncrese ));
        
    
        
        [self updateTempo];

    }else if([TempoLbl.text integerValue]>290 && [TempoLbl.text integerValue]<300)
    
    {
    
    
    }
    
}

- (IBAction)tempoUPAction:(id)sender {
    
    if ([TempoLbl.text integerValue]<=299) {

    
    tempoIncrese=tempoIncrese+0.01;
    
          NSLog(@"%f",tempoIncrese );
        
        
        
    TempoLbl.text=[NSString stringWithFormat:@"%d",[TempoLbl.text integerValue]+1];
        tempoFinal=([[[dic objectAtIndex:indexValue] objectForKey:@"tempo_value"] floatValue]+tempoIncrese);
        

    [mDiracAudioPlayer changeDuration: 1/tempoFinal];
    
    [self updateTempo];
    NSLog(@"%f",tempoIncrese );
     
        
                 NSLog(@"%f",([[[dic objectAtIndex:indexValue] objectForKey:@"tempo_value"] floatValue]+tempoIncrese));
    }
}
- (IBAction)TempoDownAction:(id)sender {
    
      if ([TempoLbl.text integerValue]>=1) {
        tempoIncrese=tempoIncrese-0.01;
        NSLog(@"%f",tempoIncrese );
    

    TempoLbl.text=[NSString stringWithFormat:@"%d",[TempoLbl.text integerValue]-1];
          
          
            tempoFinal=([[[dic objectAtIndex:indexValue] objectForKey:@"tempo_value"] floatValue]+tempoIncrese);
          
    [mDiracAudioPlayer changeDuration: 1/tempoFinal];
          
          
      
          
  NSLog(@"%f",tempoIncrese );
           NSLog(@"%f",([[[dic objectAtIndex:indexValue] objectForKey:@"tempo_value"] floatValue]+tempoIncrese) );
        
          
    [self updateTempo];
      }
}
- (IBAction)pitchUpAction:(id)sender {
//      pitchIncrease=pitchIncrease+1;
//        NSLog(@"%d",pitchIncrease);
    if (pitchIncrease<Pitcharr.count-1) {
        pitchIncrease=pitchIncrease+1;
        PitchLbl.text=[Pitcharr objectAtIndex:pitchIncrease];
        [mDiracAudioPlayer changePitch:powf(2.f, (int)pitchIncrease / 12.f)];
        [self updatePitch];
    }
}
- (IBAction)pitchDownAction:(id)sender {
//       NSLog(@"%d",pitchIncrease);
// pitchIncrease=pitchIncrease-1;
//    NSLog(@"%d",pitchIncrease);
    
   if (pitchIncrease>0) {
    pitchIncrease=pitchIncrease-1;
    PitchLbl.text=[Pitcharr objectAtIndex:pitchIncrease];
    [mDiracAudioPlayer changePitch:powf(2.f, (int)pitchIncrease / 12.f)];
    [self updatePitch];
   }
}

-(void)updateTempo
{
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"italeemPresets.sqlite"];
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    
    
    NSString *insertQuery = [NSString stringWithFormat:@"UPDATE presets_table SET tempo = '%@' ,tempo_value= '%@' WHERE id = '%@'", TempoLbl.text,[NSString stringWithFormat:@"%f" ,tempoFinal], [[dic objectAtIndex:indexValue] objectForKey:@"id"]];
    [database executeUpdate:insertQuery];
    [database close];
}
-(void)updatePitch
{
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsPath = [paths objectAtIndex:0];
    NSString *dbPath = [docsPath stringByAppendingPathComponent:@"italeemPresets.sqlite"];
    
    FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
    [database open];
    
    
    NSString *insertQuery = [NSString stringWithFormat:@"UPDATE presets_table SET pitch_name = '%@' ,pitch_value= '%@' WHERE id = '%@'", PitchLbl.text,[NSString stringWithFormat:@"%d" ,pitchIncrease], [[dic objectAtIndex:indexValue] objectForKey:@"id"]];
    [database executeUpdate:insertQuery];
    [database close];
}
@end
