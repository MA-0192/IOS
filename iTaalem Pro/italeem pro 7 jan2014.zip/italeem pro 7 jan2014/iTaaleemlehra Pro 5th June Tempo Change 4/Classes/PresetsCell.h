//
//  PresetsCell.h
//  DiracAudioPlayerExample
//
//  Created by Vivek Yadav on 11/20/13.
//
//

#import <UIKit/UIKit.h>

@interface PresetsCell : UITableViewCell

@end
