//
//  PresetsViewController.m
//  DiracAudioPlayerExample
//
//  Created by Vivek Yadav on 11/19/13.
//
//

#import "PresetsViewController.h"
#import "PresetPlayerViewController.h"
#import <Twitter/Twitter.h>
@interface PresetsViewController ()

@end

@implementation PresetsViewController
//static sqlite3 *database = nil;
//static sqlite3_stmt *statement = nil;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Presets", @"Presets");
       //  self.tabBarItem.image = [UIImage imageNamed:@"maps.png"];
        self.tabBarItem.title=@"Presets";
        
        
        [  self.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                   [UIColor whiteColor], UITextAttributeTextColor,
                                                   [NSValue valueWithUIOffset:UIOffsetMake(0,0)], UITextAttributeTextShadowOffset,
                                                   [UIFont boldSystemFontOfSize:12], UITextAttributeFont, nil]
                                         forState:UIControlStateNormal];
        
        
        [self.tabBarItem setFinishedSelectedImage:[UIImage imageNamed:@"maps.png"] withFinishedUnselectedImage:[UIImage imageNamed:@"maps.png"]];

    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
  //    dic=[[NSMutableDictionary alloc]init];
      commonarray=[[NSMutableArray alloc]init];
    BOOL isAtLeast7 = [[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0;
    
    if ( isAtLeast7 ) {
        self.edgesForExtendedLayout=UIRectEdgeNone;
        
        self.navigationController.navigationBar.translucent=NO;
    }
    UILongPressGestureRecognizer *lpgr = [[UILongPressGestureRecognizer alloc]
                                          initWithTarget:self action:@selector(handleLongPress:)];
    lpgr.minimumPressDuration = 1.0; //seconds
    lpgr.numberOfTouchesRequired = 1;
    lpgr.numberOfTapsRequired = 0;
 //   lpgr.delegate = self;
    [tableview addGestureRecognizer:lpgr];    
 }
-(void)handleLongPress:(UILongPressGestureRecognizer *)gestureRecognizer
{
    CGPoint p = [gestureRecognizer locationInView:tableview];
    
 indexPath_gesture = [tableview indexPathForRowAtPoint:p];
    if (indexPath_gesture == nil)
    {
        NSLog(@"long press on table view but not on a row");
    }
    else
    {
        
        if (gestureRecognizer.state == UIGestureRecognizerStateBegan)
            //or check for UIGestureRecognizerStateEnded instead
        {
            UIAlertView* dialog = [[UIAlertView alloc] init];
            [dialog setDelegate:self];
            [dialog setTitle:@"Change Preset Name"];
            [dialog setMessage:@"Please enter new preset name"];
            [dialog addButtonWithTitle:@"Cancel"];
            [dialog addButtonWithTitle:@"OK"];
            dialog.tag=1;
            dialog.alertViewStyle = UIAlertViewStylePlainTextInput;
            
            //      UITextField * nameField = [[UITextField alloc] initWithFrame:CGRectMake(20.0, 20, 245.0, 25.0)];
            //        [nameField setBackgroundColor:[UIColor whiteColor]];
            //        [dialog addSubview:nameField];
            
            
        
            
            
            
            CGAffineTransform moveUp = CGAffineTransformMakeTranslation(0.0, 100.0);
            [dialog setTransform: moveUp];
            [dialog show];

        }
        
        
       
    }
    
   
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if ([alertView textFieldAtIndex:0].text.length>0) {
        
        
        
        
        
        if (buttonIndex==1) {
        
            if (![alertView textFieldAtIndex:0].text.length>0) {
               [alertView textFieldAtIndex:0].text=@"Untitled preset";
            }

            
            NSString *databasePath = [self databasePath];
            FMDatabase *database = [FMDatabase databaseWithPath:databasePath];
            [database open];
            
            
//               NSLog(@"%@",[indexPath_gesture indexPathByRemovingLastIndex]);
//               NSLog(@"%@",[commonarray objectAtIndex:indexPath_gesture] );
            NSLog(@"%@",[[commonarray objectAtIndex:indexPath_gesture.row] objectForKey:@"id"]);
            
//           NSString *updateQuery= [NSString stringWithFormat:@"UPDATE presets_table SET preset_name=%@ WHERE id=%@",,];
            
            
    BOOL isSuccess = [database executeUpdate:@"UPDATE presets_table SET preset_name=? WHERE id=?",[alertView textFieldAtIndex:0].text,[[commonarray objectAtIndex:indexPath_gesture.row] objectForKey:@"id"]];
            
            if (isSuccess) {
                // Fetch all users
                FMResultSet *results = [database executeQuery:@"select * from presets_table"];
                
                   [commonarray removeAllObjects];
                
                while([results next]) {
                    NSString *name = [results stringForColumn:@"audio_name"];
                    NSString *phone  = [results stringForColumn:@"tempo"];
                    //   NSLog(@"audio_name: %@ - %@",name, phone);
                    
                    NSLog(@"%@",[results stringForColumn:@"preset_name"]);
                    
                           [commonarray addObject:[results resultDict]];
                    
                    
                    
                }
                
                
                UIAlertView *alert=[[UIAlertView alloc]initWithTitle:nil message:@"Preset name changed." delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
                [alert show];
                alert=nil;
            }
            
            [database close];
            
            [tableview reloadData];
            

        }
        
        
        
        
    }
}
-(void)viewWillAppear:(BOOL)animated
{
     tableview.editing=NO;
    [commonarray removeAllObjects];
    NSString *databasePath = [self databasePath];
    FMDatabase *database = [FMDatabase databaseWithPath:databasePath];
    [database open];
    
    FMResultSet *results = [database executeQuery:@"select * from presets_table"];
    while([results next]) {
        NSString *name = [results stringForColumn:@"audio_name"];
        NSString *phone  = [results stringForColumn:@"tempo"];
        NSLog(@"audio_name: %@ - %@",name, phone);
        
        
        [commonarray addObject:[results resultDict]];
    }
    [database close];
    
    NSLog(@"%@",commonarray);
//   addBtn =[[UIBarButtonItem alloc] initWithTitle:@"+" style:UIBarButtonItemStylePlain target:self action:@selector(addBtnAction)];
//    
//    [addBtn setTitleTextAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:28]}
//                                     forState:UIControlStateNormal];
//    self.navigationItem.leftBarButtonItem = addBtn;
//    
//    UIBarButtonItem* fbBtn =[[UIBarButtonItem alloc] initWithTitle:@"fb" style:UIBarButtonItemStyleBordered target:self action:@selector(fbBtnAction)];

    
//    UIBarButtonItem*twBtn =[[UIBarButtonItem alloc] initWithTitle:@"tw" style:UIBarButtonItemStyleBordered target:self action:@selector(twBtnAction)];
//
    EditBtn =[[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStyleBordered target:self action:@selector(EditBtnAction)];
    
    NSArray *tempArray2= [[NSArray alloc] initWithObjects:EditBtn,nil];
    self.navigationItem.rightBarButtonItems=tempArray2;
    [tableview reloadData];
 }
#pragma mark- buttons methods
-(void)EditBtnAction
{
    if ([EditBtn.title isEqualToString:@"Edit"]) {
            tableview.editing=YES;
        [EditBtn setTitle:@"Done"];
    }else
    {
        tableview.editing=NO;
      [EditBtn setTitle:@"Edit"];
    }
}
-(void)addBtnAction
{
    NSString *databasePath = [self databasePath];
    FMDatabase *database = [FMDatabase databaseWithPath:databasePath];
    [database open];
    
    BOOL isSuccess = [database executeUpdate:@"INSERT INTO presets_table (main_cat,sub_cat, instrument,tempo,tempo_value,pitch_name,pitch_value,audio_name,audio_type,audio_name2,audio_type2) VALUES (?,?,?,?,?,?,?,?,?,?,?);",[SharedData sharedObj].MainCat,[SharedData sharedObj].SubCat,[SharedData sharedObj].InstrumentCat, [NSString stringWithFormat:@"%d",[[SharedData sharedObj].Tempo integerValue]],[NSString stringWithFormat:@"%f",[[SharedData sharedObj].tempo_value floatValue]]  ,[SharedData sharedObj].pitch,[NSString stringWithFormat:@"%d",[[SharedData sharedObj].pitch_value integerValue]],[SharedData sharedObj].audioName1,[SharedData sharedObj].audioType1,[SharedData sharedObj].audioName2,[SharedData sharedObj].audioType2];
    
    if (isSuccess) {
        // Fetch all users
        FMResultSet *results = [database executeQuery:@"select * from presets_table"];
        [commonarray removeAllObjects];
        while([results next]) {
            NSString *name = [results stringForColumn:@"audio_name"];
            NSString *phone  = [results stringForColumn:@"tempo"];
            NSLog(@"audio_name: %@ - %@",name, phone);
            [commonarray addObject:[results resultDict]];
        }

        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:nil message:@"Preset successfully added" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];
        alert=nil;
    }
    [database close];
    NSLog(@"%@",commonarray);

//    [dic setValue:[SharedData sharedObj].Tempo forKey:@"tempo"];
//    [dic setValue:[SharedData sharedObj].pitch forKey:@"pitch"];
//    [dic setValue:[SharedData sharedObj].MainCat forKey:@"MainCat"];
//    [dic setValue:[SharedData sharedObj].SubCat forKey:@"SubCat"];
//    [dic setValue:[SharedData sharedObj].InstrumentCat forKey:@"InstrumentCat"];
//      [dic setValue:[SharedData sharedObj].arrayIndex forKey:@"index"];
    
    
     [tableview reloadData];
 }
-(NSString *)databasePath{
    
    NSString *documents=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString *databasePath=[documents stringByAppendingPathComponent:@"italeemPresets.sqlite"];
    NSFileManager *fileManger=[NSFileManager defaultManager];
    if (![fileManger fileExistsAtPath:databasePath]) {
        NSString *bundlePath=[[NSBundle mainBundle]pathForResource:@"italeemPresets" ofType:@"sqlite"];
        [fileManger copyItemAtPath:bundlePath toPath:databasePath error:nil];
        
    }
    return  databasePath;
}
-(void)fbBtnAction
{
    
}

-(void)twBtnAction
{
    CGSize contextSize;
    if([[UIScreen mainScreen] bounds].size.height == 480)
    {
        contextSize=CGSizeMake(320,480);
    }else {
        contextSize=CGSizeMake(320,568);
    }
    
	UIGraphicsBeginImageContext(contextSize);
	[self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *screenshot = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();

    
    TWTweetComposeViewController *twitter = [[TWTweetComposeViewController alloc] init];
    NSString *sStatusMessage =@"You can more downloads from- http://www.ipooja.com/  or https://twitter.com/iPooja";
    [twitter setInitialText:sStatusMessage];
    [twitter addImage:screenshot];
    [self presentModalViewController:twitter animated:YES];
    
}
#pragma mark- table delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
           return commonarray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = nil;
    if(cell==nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"xx"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.contentView.backgroundColor = [UIColor clearColor];
        cell.backgroundColor=[UIColor clearColor];
    }
    
    NSLog(@"%@",[ NSString stringWithFormat:@"%@, %@, %@",[[commonarray objectAtIndex:indexPath.row] objectForKey:@"main_cat"],[[commonarray objectAtIndex:indexPath.row] objectForKey:@"sub_cat"],[[commonarray objectAtIndex:indexPath.row] objectForKey:@"instrument"] ]);
    
    UILabel * presetNamelabel=[[UILabel alloc] initWithFrame:CGRectMake(20, 5, 290, 30)];
    presetNamelabel.backgroundColor = [UIColor clearColor];
    presetNamelabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:19];
    presetNamelabel.textColor = [UIColor whiteColor];
    presetNamelabel.text=[[commonarray objectAtIndex:indexPath.row] objectForKey:@"preset_name"];
    presetNamelabel.textAlignment=NSTextAlignmentLeft;
    [cell.contentView addSubview:presetNamelabel];

    
    UILabel * audioName=[[UILabel alloc] initWithFrame:CGRectMake(20, 30, 290, 30)];
    audioName.backgroundColor = [UIColor clearColor];
    audioName.font = [UIFont fontWithName:@"Helvetica" size:16];
    audioName.textColor = [UIColor whiteColor];
    audioName.text=[ NSString stringWithFormat:@"%@, %@",[[commonarray objectAtIndex:indexPath.row] objectForKey:@"main_cat"],[[commonarray objectAtIndex:indexPath.row] objectForKey:@"sub_cat"] ];
    audioName.textAlignment=NSTextAlignmentLeft;
    [cell.contentView addSubview:audioName];
    

    UILabel * instrumentLbl=[[UILabel alloc] initWithFrame:CGRectMake(140, 55, 120, 30)];
    instrumentLbl.backgroundColor = [UIColor clearColor];
    instrumentLbl.font = [UIFont fontWithName:@"Helvetica" size:16];
    instrumentLbl.textColor = [UIColor whiteColor];
    instrumentLbl.text=[NSString stringWithFormat:@"%@",[[commonarray objectAtIndex:indexPath.row] objectForKey:@"instrument"]];
    instrumentLbl.textAlignment=NSTextAlignmentLeft;
    [cell.contentView addSubview:instrumentLbl];

    
    UILabel * pitch=[[UILabel alloc] initWithFrame:CGRectMake(20, 55, 90, 30)];
    pitch.backgroundColor = [UIColor clearColor];
    pitch.font = [UIFont fontWithName:@"Helvetica" size:16];
    pitch.textColor = [UIColor whiteColor];
    pitch.text=[NSString stringWithFormat:@"%@,",[[commonarray objectAtIndex:indexPath.row] objectForKey:@"pitch_name"]];
    pitch.textAlignment=NSTextAlignmentLeft;
    [cell.contentView addSubview:pitch];
    
    
    UILabel * tempo=[[UILabel alloc] initWithFrame:CGRectMake(50, 55, 90, 30)];
    tempo.backgroundColor = [UIColor clearColor];
    tempo.font = [UIFont fontWithName:@"Helvetica" size:16];
    tempo.textColor = [UIColor whiteColor];
    tempo.text=[NSString stringWithFormat:@"%@ bpm ,",[[commonarray objectAtIndex:indexPath.row] objectForKey:@"tempo"]];
    tempo.textAlignment=NSTextAlignmentLeft;
    [cell.contentView addSubview:tempo];

//
//    Descriptionlabel=[[UILabel alloc] initWithFrame:CGRectMake(20, 60, 245, 30)];
//    
//    if (searching==YES) {
//        namelabel.text = [NSString stringWithFormat:@"%@",[searchDataArr objectAtIndex:indexPath.row]];
//        
//        Descriptionlabel.text = [NSString stringWithFormat:@"%@",[[searchDataArr objectAtIndex:indexPath.row] objectAtIndex:1]];
//        
//    }else
//    {
//        namelabel.text = [NSString stringWithFormat:@"%@",[[subCategoryArray objectAtIndex:indexPath.row] objectAtIndex:0]];
//        Descriptionlabel.text = [NSString stringWithFormat:@"%@",[[subCategoryArray objectAtIndex:indexPath.row] objectAtIndex:1]];
//        
//        
//    }
//    
//    
//    namelabel.backgroundColor = [UIColor clearColor];
//    namelabel.font = [UIFont fontWithName:@"HoboStd" size:20];
//    namelabel.textColor = [UIColor whiteColor];
//    namelabel.textAlignment=NSTextAlignmentCenter;
//    [cell.contentView addSubview:namelabel];
//    if(Showlb)
//    {
//        
//        Descriptionlabel.backgroundColor = [UIColor clearColor];
//        Descriptionlabel.font = [UIFont fontWithName:@"HoboStd" size:20];
//        Descriptionlabel.textColor = [UIColor whiteColor];
//        Descriptionlabel.textAlignment=NSTextAlignmentCenter;
//        [cell.contentView addSubview:Descriptionlabel];
//    }
//    else
//        
//    {
//        Descriptionlabel.hidden=YES;
//    }
    
    cell.accessoryType = UITableViewCellAccessoryNone;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {

        NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *docsPath = [paths objectAtIndex:0];
        NSString *dbPath = [docsPath stringByAppendingPathComponent:@"italeemPresets.sqlite"];
        
        FMDatabase *database = [FMDatabase databaseWithPath:dbPath];
        [database open];
        
        
        
        NSString *deleteQuery = [ NSString stringWithFormat:@"DELETE FROM presets_table WHERE id =%@",[[commonarray objectAtIndex:indexPath.row] objectForKey:@"id"]];
        [database executeUpdate:deleteQuery];
        [database close];
        
        [commonarray removeObjectAtIndex:indexPath.row];
        [tableView reloadData];
        
        
        UIAlertView *alert=[[UIAlertView alloc]initWithTitle:nil message:@"Preset deleted." delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];
        alert=nil;

    }
    else if (editingStyle == UITableViewCellEditingStyleInsert)
    {
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    PresetPlayerViewController *playerPreset;
//    
//      if ([UIScreen mainScreen].bounds.size.height==480)
//      {
//          playerPreset=[[PresetPlayerViewController alloc]initWithNibName:@"PresetPlayerViewController" bundle:nil];
//      }else
//      {
//               playerPreset=[[PresetPlayerViewController alloc]initWithNibName:@"PresetPlayerViewController_iPod" bundle:nil];
//      }
//    
//    
//    [playerPreset setDic:commonarray];
//    [playerPreset setIndexNumber:[NSString  stringWithFormat:@"%d", indexPath.row ]];
//    [self.navigationController pushViewController:playerPreset animated:YES];
    
    
    NSLog(@"%@",[commonarray objectAtIndex:indexPath.row]);
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"Playpresets"  object:[commonarray objectAtIndex:indexPath.row]];
       self.tabBarController.selectedIndex=0;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 100;
 }
-(void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
