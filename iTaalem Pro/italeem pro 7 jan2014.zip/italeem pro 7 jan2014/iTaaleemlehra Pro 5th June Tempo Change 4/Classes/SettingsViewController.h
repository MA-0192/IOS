//
//  SettingsViewController.h
//  DiracAudioPlayerExample
//
//  Created by Vivek Yadav on 11/19/13.
//
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
@interface SettingsViewController : UIViewController
{
    MPMusicPlayerController *musicPlayer;
    IBOutlet UISwitch *SwitchBackground;
    IBOutlet UISwitch *Switchdisplayaudio;
    __weak IBOutlet UISwitch *LockScreenSwitch;
    __weak IBOutlet UISlider *volumeSlider;
    __weak IBOutlet UISlider *BrightnessSlider;
    
    
}
- (IBAction)resetSettingsBtn:(id)sender;
- (IBAction)sliderVolumeChange:(id)sender;
- (IBAction)brightnesssliderValueChange:(id)sender;
- (IBAction)lockScreenSwitchAction:(id)sender;
- (IBAction)displayAudioInfo:(id)sender;
- (IBAction)AudioSwitch:(id)sender;
@end
