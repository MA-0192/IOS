//
//  SettingsViewController.m
//  DiracAudioPlayerExample
//
//  Created by Vivek Yadav on 11/19/13.
//
//
#import "SettingsViewController.h"
@interface SettingsViewController ()
@end
@implementation SettingsViewController
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Settings", @"Settings");
     //   self.tabBarItem.image = [UIImage imageNamed:@"settings.png"];
        self.tabBarItem.title=@"Settings";
        
        
        [  self.tabBarItem setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                   [UIColor whiteColor], UITextAttributeTextColor,
                                                   [NSValue valueWithUIOffset:UIOffsetMake(0,0)], UITextAttributeTextShadowOffset,
                                                   [UIFont boldSystemFontOfSize:12], UITextAttributeFont, nil]
                                         forState:UIControlStateNormal];
        
        
        [self.tabBarItem setFinishedSelectedImage:[UIImage imageNamed:@"settings.png"] withFinishedUnselectedImage:[UIImage imageNamed:@"settings.png"]];
        

        
    }
    return self;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
       musicPlayer = [MPMusicPlayerController iPodMusicPlayer];
    
    [musicPlayer setRepeatMode:MPMusicRepeatModeNone];
    
    

    
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(handleVolumeChangedFromOutSideApp:)
                                                 name:MPMusicPlayerControllerVolumeDidChangeNotification
                                               object:musicPlayer];
    
    [musicPlayer beginGeneratingPlaybackNotifications];
    
    
//    if (  [[[NSUserDefaults standardUserDefaults] objectForKey:@"BackgroundAudio"] isEqualToString:@"on"]) {
//        SwitchBackground.on=YES;
//    }else
//    {
//        SwitchBackground.on=NO;
//    }
//    [[NSNotificationCenter defaultCenter]
//     postNotificationName:@"BackgroundAudio"
//     object:self];
    
    
//    if (  [[[NSUserDefaults standardUserDefaults] objectForKey:@"DisplayAudio"] isEqualToString:@"on"]) {
//        Switchdisplayaudio.on=YES;
//    }else
//    {
//        Switchdisplayaudio.on=NO;
//    }
//    [[NSNotificationCenter defaultCenter]
//     postNotificationName:@"DisplayAudio"
//     object:self];
//    
    
    
    if (  [[[NSUserDefaults standardUserDefaults] objectForKey:@"LockScreen"] isEqualToString:@"on"]) {
        LockScreenSwitch.on=YES;
           [[UIApplication sharedApplication] setIdleTimerDisabled: YES];
        
        
    }else
    {
        LockScreenSwitch.on=NO;
           [[UIApplication sharedApplication] setIdleTimerDisabled: NO];
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)resetSettingsBtn:(id)sender {
    
    
    UIAlertView* dialog = [[UIAlertView alloc] init];
    [dialog setDelegate:self];
    [dialog setTitle:@"Are you want to reset all settings"];
    [dialog addButtonWithTitle:@"No"];
    [dialog addButtonWithTitle:@"yes"];
    [dialog show];
  
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex==1) {
        
        volumeSlider.value=0.5;
        
        [[NSUserDefaults standardUserDefaults] setObject:@"off" forKey:@"LockScreen"];
        LockScreenSwitch.on=NO;
        [[UIApplication sharedApplication] setIdleTimerDisabled: YES];
        
        
        BrightnessSlider.value=0.5;
       //  [[UIScreen mainScreen] setBrightness: BrightnessSlider.value];

        
    }
}
- (IBAction)sliderVolumeChange:(id)sender {
        musicPlayer.volume = volumeSlider.value;
}

- (IBAction)brightnesssliderValueChange:(id)sender {
    
    [[UIScreen mainScreen] setBrightness: BrightnessSlider.value];
    
    NSLog(@"%F",BrightnessSlider.value);
}

- (IBAction)lockScreenSwitchAction:(id)sender {
    
    if (LockScreenSwitch.on) {
        
        [[NSUserDefaults standardUserDefaults] setObject:@"on" forKey:@"LockScreen"];
        LockScreenSwitch.on=YES;
         [[UIApplication sharedApplication] setIdleTimerDisabled: YES];
        
    }else
    {
        [[NSUserDefaults standardUserDefaults] setObject:@"off" forKey:@"LockScreen"];
        LockScreenSwitch.on=NO;
         [[UIApplication sharedApplication] setIdleTimerDisabled: NO];
    }
}
- (IBAction)displayAudioInfo:(id)sender {
    
    if (Switchdisplayaudio.on) {
    
        [[NSUserDefaults standardUserDefaults] setObject:@"on" forKey:@"DisplayAudio"];
        Switchdisplayaudio.on=YES;
    }else
    {
        [[NSUserDefaults standardUserDefaults] setObject:@"off" forKey:@"DisplayAudio"];
        Switchdisplayaudio.on=NO;
    }
    [[NSNotificationCenter defaultCenter]
     postNotificationName:@"DisplayAudio"
     object:self];
}
- (IBAction)AudioSwitch:(id)sender {
    
//    if (SwitchBackground.on) {
//      
//        [[NSUserDefaults standardUserDefaults] setObject:@"on" forKey:@"BackgroundAudio"];
//         SwitchBackground.on=YES;
//        
//    }else
//    {
//       
//        [[NSUserDefaults standardUserDefaults] setObject:@"off" forKey:@"BackgroundAudio"];
//  SwitchBackground.on=NO;
//    }
//    
//    NSLog(@"%@",[[NSUserDefaults standardUserDefaults] objectForKey:@"BackgroundAudio"]);
//    
//    [[NSNotificationCenter defaultCenter]
//     postNotificationName:@"BackgroundAudio"
//     object:self];
//    
    
}
#pragma mark- volume method

- (void)handleVolumeChangedFromOutSideApp:(id)notification {
    
    [volumeSlider setValue:musicPlayer.volume animated:YES];
}
@end
