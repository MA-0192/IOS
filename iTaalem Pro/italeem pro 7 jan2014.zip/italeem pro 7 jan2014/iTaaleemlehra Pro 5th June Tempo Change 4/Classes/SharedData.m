//
//  SharedData.m
//  singletonClassDemo
//
//  Created by Vivek Yadav on 11/13/13.
//  Copyright (c) 2013 Mediaagility. All rights reserved.
//

#import "SharedData.h"

@implementation SharedData
@synthesize globalObject;
@synthesize pitch;
@synthesize MainCat;
@synthesize SubCat;
@synthesize InstrumentCat;
@synthesize arrayIndex;


@synthesize audioName1;
@synthesize audioType1;
@synthesize audioName2;
@synthesize audioType2,tempo_value,pitch_value;



+(SharedData *)sharedObj
{
    static SharedData * obj1=nil;
    
    @synchronized(self)
    {
        if(!obj1)
        {
            obj1 = [[SharedData alloc] init];
            
        }
        
    }
    return obj1;
}

@end
