//
//  DurationView.h
//  DiracAudioPlayerExample
//
//  Created by Vivek Yadav on 11/20/13.
//
//

#import <UIKit/UIKit.h>

@interface DurationView : UIView

@end
