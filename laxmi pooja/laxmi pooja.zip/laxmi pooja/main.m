//
//  main.m
//  iChant
//
//  Created by iPhone Dev 2 on 12/22/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "iChantAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([iChantAppDelegate class]));
    }
}
